[app]
title = RetailPro Commercial
package.name = retailprocommercial
package.domain = com.retailpro
source.dir = .
source.include_exts = py,png
source.exclude_dirs = _desktop_data,tests,bin,.github,icons
version = 2.0
requirements = python3,sqlite3,flask,werkzeug,jinja2,markupsafe,itsdangerous,click,blinker,pillow,reportlab==3.6.13
icon.filename = %(source.dir)s/data/icon.png
presplash.filename = %(source.dir)s/data/presplash.png
android.presplash_color = #1B2D4F
orientation = portrait
fullscreen = 0

# Run the Flask app inside an Android WebView
p4a.bootstrap = webview
p4a.port = 5000

android.permissions = INTERNET
android.api = 34
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
