import os, sys, glob, re
os.environ["ANDROID_ARGUMENT"]="/x"; os.environ["ANDROID_PRIVATE"]="/tmp/andpriv"
sys.path.insert(0,"/home/claude/RetailPro_Android")
import main
rp=main.rp
print("cwd:",os.getcwd()); print("db exists in private dir:",os.path.exists("/tmp/andpriv/retailpro_data/retailpro_shop.db"))
c=rp.app.test_client()
# owner login
r=c.post("/owner-login",data={"username":"admin","password":"1234"},follow_redirects=True); print("login",r.status_code)
# crawl all simple GET routes
bad=[];ok=0
for rule in rp.app.url_map.iter_rules():
    if "GET" not in rule.methods or rule.arguments or rule.endpoint=="static": continue
    for lg in ("ur","en"):
        with c.session_transaction() as s: s["lang"]=lg
        r=c.get(rule.rule,follow_redirects=True)
        if r.status_code>=400: bad.append((rule.rule,lg,r.status_code))
        else: ok+=1
print("GET pages OK:",ok,"errors:",bad)
c.post("/owner-login",data={"username":"admin","password":"1234"})
# create product + sale to test invoice/pdf
c.post("/products/add",data={"name":"Test Item","category":"x","buying_price":"10","selling_price":"15","current_stock":"50","min_stock":"1","barcode":"123"},follow_redirects=True)
print([str(r) for r in rp.app.url_map.iter_rules() if "sale" in r.rule][:12])
pid=rp.sqlite3.connect("retailpro_shop.db").execute("SELECT id FROM products WHERE name='Test Item'").fetchone()[0]
c.post("/sales",data={"product_id":pid,"quantity":"3"},follow_redirects=True)
r=c.post("/sales/checkout",data={"paid":"45","discount":"0","customer_id":"","notes":""},follow_redirects=False); print("checkout",r.status_code,r.headers.get("Location"))
sid=int(r.headers["Location"].rstrip("/").split("/")[-1]) if "invoice" in (r.headers.get("Location") or "") else 1
r=c.get(f"/sales/invoice/{sid}"); print("invoice",r.status_code, b"Test Item" in r.data)
for lg in ("en","ur"):
    with c.session_transaction() as s: s["lang"]=lg
    r=c.get(f"/sales/invoice/{sid}/pdf"); print("pdf",lg,r.status_code,r.mimetype,r.data[:5])
print("pdf written to private tmp:",glob.glob("/tmp/andpriv/retailpro_data/tmp/*.pdf"))
r=c.get("/backup"); print("backup",r.status_code,len(r.data)); print("backups:",glob.glob("/tmp/andpriv/retailpro_data/retailpro_backups/*"))
r=c.get("/health"); print("health",r.json)
