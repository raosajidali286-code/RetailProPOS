# RetailPro Commercial – Android project

Your original app is included **byte-for-byte unchanged** as `retailpro_app.py`
(SHA-256 b78bdda4…3f07). `main.py` is a small launcher; it only handles Android needs
(private storage for DB/backups, a writable folder for the PDF's hard-coded `/tmp`,
per-install session secret, serving on 127.0.0.1 inside an in-app WebView).
Icon: your exact image (`data/icon.png`); launcher sizes in `icons/`.

## Get the APK (no installs on your side)
1. Create a free GitHub account, make a new **private** repository.
2. Upload the *contents* of this folder (keep `.github/workflows/build-apk.yml`).
3. Open the **Actions** tab -> "Build RetailPro Commercial APK" -> **Run workflow**.
4. Wait ~25-40 min (first build). Download **RetailPro-Commercial-APK** from the run's Artifacts.
5. Unzip, send the `.apk` to phones, allow "Install unknown apps", install.

Alternative: on a Linux PC, run `pip install buildozer "cython<3"` then `buildozer -v android debug`; APK appears in `bin/`.

## Notes
- The APK is debug-signed: installs/shares fine. Google Play would need a release keystore.
- Data (database, backups) is stored in the app's private storage; uninstalling deletes it.
- Default owner login is unchanged: admin / 1234 (change it in Settings).
