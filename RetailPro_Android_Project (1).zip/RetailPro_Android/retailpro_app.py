#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RetailPro Shop Manager
Single-file Flask + SQLite POS; commercial-ready foundation for Android packaging and future cloud licensing.

Main features:
- Fast product/customer/supplier search
- Barcode lookup + mobile BarcodeDetector scanner
- Multi-item sales and purchases
- Automatic selling price / stock / cost information
- Sales and purchase discounts
- Customer and supplier returns
- Customer/supplier ledgers and balances
- Printable invoice + PDF invoice (requires reportlab for PDF)
- Owner login for management; sales screen remains open for staff
- Mobile-first colorful UI
- SQLite backup
"""
import os
import sys
import sqlite3
import shutil
import hashlib
import secrets
from datetime import datetime, date
from functools import wraps

try:
    from flask import Flask, request, render_template_string, redirect, url_for, flash, session, g, jsonify, send_file
except ImportError:
    print("Error: Flask is not installed.")
    print("Install it in Termux with: pip install flask")
    sys.exit(1)

app = Flask(__name__)
app.secret_key = os.environ.get("RETAILPRO_SECRET", "retailpro-secret-2026-change-me")
DB_NAME = "retailpro_shop.db"
BACKUP_DIR = "retailpro_backups"
DEFAULT_OWNER_USER = "admin"
DEFAULT_OWNER_PASSWORD = "1234"

LANG_DATA = {
    "en": {
        "title":"RetailPro Shop Manager", "dashboard":"Dashboard", "products":"Products", "stock":"Stock",
        "customers":"Customers", "suppliers":"Suppliers", "sales":"Sales", "purchases":"Purchases",
        "expenses":"Expenses", "returns":"Returns", "reports":"Reports", "settings":"Settings",
        "backup":"Backup", "login":"Owner Login", "logout":"Logout", "owner":"Owner", "staff":"Staff",
        "search":"Search name / barcode...", "save":"Save", "add":"Add", "edit":"Edit", "delete":"Delete",
        "name":"Name", "phone":"Phone", "address":"Address", "quantity":"Quantity", "price":"Price",
        "buy_price":"Buy Price", "sell_price":"Sell Price", "discount":"Discount", "paid":"Paid", "credit":"Credit",
        "total":"Total", "back":"Back", "scan":"Scan Barcode", "checkout":"Complete Sale", "walkin":"Walk-in / Cash",
        "return":"Return", "customer_return":"Customer Return", "supplier_return":"Supplier Return", "supplier":"Supplier",
        "customer":"Customer", "invoice":"Invoice", "print":"Print", "pdf":"PDF", "close":"Close", "management":"Management",
        "today_sales":"Today's Sales", "today_profit":"Today's Profit", "receivable":"Receivable", "payable":"Payable",
    },
    "ur": {
        "title":"ریٹیل پرو شاپ مینیجر", "dashboard":"ڈیش بورڈ", "products":"پروڈکٹس", "stock":"اسٹاک",
        "customers":"گاہک", "suppliers":"سپلائرز", "sales":"فروخت", "purchases":"خریداری", "expenses":"اخراجات",
        "returns":"واپسی", "reports":"رپورٹس", "settings":"ترتیبات", "backup":"بیک اپ", "login":"اونر لاگ اِن",
        "logout":"لاگ آؤٹ", "owner":"اونر", "staff":"اسٹاف", "search":"نام / بارکوڈ تلاش کریں...", "save":"محفوظ کریں",
        "add":"شامل کریں", "edit":"ترمیم", "delete":"حذف", "name":"نام", "phone":"فون", "address":"پتہ",
        "quantity":"مقدار", "price":"قیمت", "buy_price":"خرید قیمت", "sell_price":"فروخت قیمت", "discount":"ڈسکاؤنٹ",
        "paid":"جمع رقم", "credit":"ادھار", "total":"کل", "back":"واپس", "scan":"بارکوڈ اسکین", "checkout":"فروخت مکمل کریں",
        "walkin":"واک اِن / نقد", "return":"واپسی", "customer_return":"گاہک کی واپسی", "supplier_return":"سپلائر کو واپسی",
        "supplier":"سپلائر", "customer":"گاہک", "invoice":"بل", "print":"پرنٹ", "pdf":"PDF", "close":"بند", "management":"مینجمنٹ",
        "today_sales":"آج کی فروخت", "today_profit":"آج کا منافع", "receivable":"لینی والی رقم", "payable":"دینی والی رقم",
    }
}

def now(): return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def today(): return date.today().isoformat()
def num(v):
    try: return float(v or 0)
    except Exception: return 0.0
def money(v): return f"Rs {num(v):,.2f}".replace(",.00", ",00")
def lang(): return session.get("lang", "ur")
def T(k): return LANG_DATA.get(lang(), LANG_DATA["ur"]).get(k, k)

UI_TEXT = {
    "Owner Management Login":"اونر مینجمنٹ لاگ اِن","Owner Login":"اونر لاگ اِن","Username":"یوزرنیم","Password":"پاسورڈ","Login":"لاگ اِن",
    "Default first login: admin / 1234 — change it in Settings.":"پہلا لاگ اِن: admin / 1234 — اسے ترتیبات میں تبدیل کریں۔",
    "Product":"پروڈکٹ","Products":"پروڈکٹس","Price":"قیمت","Qty":"مقدار","Quantity":"مقدار","Total":"کل","Buy Price":"خرید قیمت","Sell Price":"فروخت قیمت",
    "Buying Price":"خرید قیمت","Selling Price":"فروخت قیمت","Opening Stock":"ابتدائی اسٹاک","Min Stock":"کم از کم اسٹاک","Barcode / QR":"بارکوڈ / QR","Barcode":"بارکوڈ","Notes":"نوٹس",
    "Save Product":"پروڈکٹ محفوظ کریں","Scan":"اسکین","Scan Barcode":"بارکوڈ اسکین","Search":"تلاش","Clear Bill":"بل صاف کریں","Customer Name":"گاہک کا نام",
    "Phone":"فون","Optional phone":"فون (اختیاری)","Name for credit sale":"ادھار فروخت کے لیے نام","Due Date":"آخری تاریخ","Subtotal":"ذیلی کل","Discount":"ڈسکاؤنٹ",
    "Paid":"جمع رقم","Change":"واپسی رقم","Credit":"ادھار","Complete Sale":"فروخت مکمل کریں","No product found":"کوئی پروڈکٹ نہیں ملا","No customer found":"کوئی گاہک نہیں ملا",
    "Scan/search a product to start the bill.":"بل شروع کرنے کے لیے پروڈکٹ تلاش کریں یا اسکین کریں۔","Clear":"صاف کریں","Save Purchase & Stock In":"خریداری محفوظ کریں اور اسٹاک شامل کریں",
    "Purchase Discount (Rs)":"خریداری ڈسکاؤنٹ (روپے)","Supplier Search":"سپلائر تلاش کریں","No supplier selected":"کوئی سپلائر منتخب نہیں","Add products.":"پروڈکٹس شامل کریں۔",
    "Select":"منتخب کریں","Stock":"اسٹاک","Extra Cost":"اضافی لاگت","Current Stock":"موجودہ اسٹاک","Category":"زمرہ","Address":"پتہ","Company":"کمپنی",
    "Opening Balance":"ابتدائی بیلنس","Reason":"وجہ","Save":"محفوظ کریں","Edit":"ترمیم","Delete":"حذف","Add":"شامل کریں","Go":"جائیں","Sales":"فروخت",
    "Profit":"منافع","Expenses":"اخراجات","Bills":"بلز","Date":"تاریخ","Customer":"گاہک","Supplier":"سپلائر","Party":"فریق","Description":"تفصیل","Type":"قسم",
    "Amount":"رقم","Payment made":"ادائیگی کی رقم","Pay Supplier":"سپلائر کو ادائیگی","Current Balance":"موجودہ بیلنس","Current Payable":"موجودہ واجب الادا",
    "Walk-in":"واک اِن","Customer Return":"گاہک کی واپسی","Supplier Return":"سپلائر کی واپسی","Customer (optional)":"گاہک (اختیاری)","Supplier (optional)":"سپلائر (اختیاری)",
    "Refund/Adjustment Price":"واپسی/ایڈجسٹمنٹ قیمت","Return Price":"واپسی قیمت","Save Customer Return":"گاہک کی واپسی محفوظ کریں","Save Supplier Return":"سپلائر کی واپسی محفوظ کریں",
    "Recent Returns":"حالیہ واپسی","New Sale":"نئی فروخت","Bill":"بل","Item":"آئٹم","Rate":"ریٹ","Shop Name":"دکان کا نام","Owner Name":"اونر کا نام",
    "Language":"زبان","Currency":"کرنسی","New Owner Password":"نیا اونر پاسورڈ","Leave blank to keep current":"موجودہ پاسورڈ رکھنے کے لیے خالی چھوڑیں",
    "Save Settings":"ترتیبات محفوظ کریں","Daily Closing":"روزانہ کلوزنگ","Close Day":"دن بند کریں","Monthly Report":"ماہانہ رپورٹ","Gross Profit":"مجموعی منافع","Net Profit":"خالص منافع",
    "This report is generated automatically for the current month. Daily closing records are stored separately.":"یہ رپورٹ موجودہ ماہ کے لیے خودکار طور پر تیار ہوتی ہے۔ روزانہ کلوزنگ کا ریکارڈ الگ محفوظ ہوتا ہے۔",
    "Owner":"اونر","Staff":"اسٹاف","Management":"مینجمنٹ","Settings":"ترتیبات","Returns":"واپسی","Reports":"رپورٹس","Backup":"بیک اپ",
    "Product added.":"پروڈکٹ شامل کر دیا گیا۔","Product updated.":"پروڈکٹ اپڈیٹ کر دیا گیا۔","Product not found.":"پروڈکٹ نہیں ملا۔",
    "Quantity must be greater than zero.":"مقدار صفر سے زیادہ ہونی چاہیے۔","Cart quantity exceeds stock.":"کارٹ کی مقدار اسٹاک سے زیادہ ہے۔",
    "Invalid quantity / stock.":"غلط مقدار / اسٹاک۔","Bill is empty.":"بل خالی ہے۔","Invalid product, quantity or price.":"غلط پروڈکٹ، مقدار یا قیمت۔",
    "Invalid return data.":"واپسی کا ڈیٹا غلط ہے۔","Return saved and stock adjusted.":"واپسی محفوظ کر دی گئی اور اسٹاک ایڈجسٹ کر دیا گیا۔",
    "Daily closing saved.":"روزانہ کلوزنگ محفوظ کر دی گئی۔","Settings saved.":"ترتیبات محفوظ کر دی گئیں۔","Logged out.":"لاگ آؤٹ ہو گیا۔","Owner login required.":"اونر لاگ اِن ضروری ہے۔",
    "ریٹیل پرو شاپ مینیجر":"RetailPro Shop Manager", "فاسٹ سیل":"Fast Sale", "خریداری":"Purchase", "نیا پروڈکٹ":"New Product",
    "پروڈکٹ ترمیم":"Edit Product", "نیا گاہک":"New Customer", "گاہک ترمیم":"Edit Customer", "گاہک کھاتہ":"Customer Ledger",
    "سپلائر کھاتہ":"Supplier Ledger", "نیا سپلائر":"New Supplier", "سپلائر ترمیم":"Edit Supplier",
    "نام یا بارکوڈ لکھیں؛ یا اسکین کریں۔ قیمت، موجودہ اسٹاک اور لاگت خودکار آئے گی۔":"Enter name or barcode, or scan it. Price, current stock and cost appear automatically.",
    "گاہک کا نام / فون":"Customer name / phone", "پروڈکٹ نام یا بارکوڈ تلاش کریں":"Search product name or barcode",
    "سپلائر کا نام، فون یا کمپنی لکھیں":"Enter supplier name, phone or company", "نام یا بارکوڈ تلاش کریں":"Search name / barcode...",
    "Due Date (اگر ادھار ہو)":"Due Date (for credit)",
    "آپ کے براؤزر میں BarcodeDetector دستیاب نہیں۔ Chrome کے تازہ ورژن میں کوشش کریں، یا اوپر بارکوڈ ٹائپ کریں۔":"BarcodeDetector is not available in your browser. Try the latest Chrome version, or type the barcode above.",
    "آپ کے براؤزر میں BarcodeDetector دستیاب نہیں۔ Chrome کے تازہ ورژن میں کوشش کریں، یا بارکوڈ اوپر ٹائپ کریں۔":"BarcodeDetector is not available in your browser. Try the latest Chrome version, or type the barcode above.",
    "Owner Only:":"صرف اونر:", "Products, customers, suppliers, purchases, returns, expenses, reports and settings are protected. Staff can use the Sales screen without owner login.":"پروڈکٹس، گاہک، سپلائر، خریداری، واپسی، اخراجات، رپورٹس اور ترتیبات محفوظ ہیں۔ اسٹاف اونر لاگ اِن کے بغیر فروخت اسکرین استعمال کر سکتا ہے۔",

    "Due Date (اگر ادھار ہو)":"Due Date (if on credit)",
    "نام یا بارکوڈ سے پروڈکٹ تلاش کریں، پھر <b>＋ Select</b> دبائیں۔":"Search by product name or barcode, then press <b>＋ Select</b>.",
    "نام یا بارکوڈ لکھیں؛ یا اسکین کریں۔ قیمت، موجودہ اسٹاک اور لاگت خودکار آئے گی۔":"Enter a name or barcode, or scan it. Price, current stock, and cost will appear automatically.",
    "Products, customers, suppliers, purchases, returns, expenses, reports and settings are protected. Staff can use the Sales screen without owner login.":"پروڈکٹس، گاہک، سپلائرز، خریداری، واپسی، اخراجات، رپورٹس اور ترتیبات محفوظ ہیں۔ اسٹاف اونر لاگ اِن کے بغیر فروخت اسکرین استعمال کر سکتا ہے۔",
    "Name":"نام", "Company":"کمپنی", "Opening Stock":"ابتدائی اسٹاک", "Min Stock":"کم از کم اسٹاک",
    "Barcode / QR":"بارکوڈ / QR", "Notes":"نوٹس", "Save Product":"پروڈکٹ محفوظ کریں",
    "Optional phone":"فون (اختیاری)", "Name for credit sale":"ادھار فروخت کے لیے نام",
    "Due Date (for credit)":"آخری تاریخ (ادھار کی صورت میں)", "Subtotal":"ذیلی کل",
    "Change":"واپسی رقم", "No product found":"کوئی پروڈکٹ نہیں ملا", "No customer found":"کوئی گاہک نہیں ملا",
    "Scan/search a product to start the bill.":"بل شروع کرنے کے لیے پروڈکٹ تلاش کریں یا اسکین کریں۔",
    "Clear Bill":"بل صاف کریں", "Save Purchase & Stock In":"خریداری محفوظ کریں اور اسٹاک شامل کریں",
    "Purchase Discount (Rs)":"خریداری ڈسکاؤنٹ (روپے)", "Supplier Search":"سپلائر تلاش کریں",
    "No supplier selected":"کوئی سپلائر منتخب نہیں", "Add products.":"پروڈکٹس شامل کریں۔",
    "Extra Cost":"اضافی لاگت", "Current Stock":"موجودہ اسٹاک", "Opening Balance":"ابتدائی بیلنس",
    "Payment made":"ادائیگی کی رقم", "Pay Supplier":"سپلائر کو ادائیگی", "Current Balance":"موجودہ بیلنس",
    "Current Payable":"موجودہ واجب الادا", "Walk-in":"واک اِن", "Refund/Adjustment Price":"واپسی/ایڈجسٹمنٹ قیمت",
    "Return Price":"واپسی قیمت", "Save Customer Return":"گاہک کی واپسی محفوظ کریں",
    "Save Supplier Return":"سپلائر کی واپسی محفوظ کریں", "Recent Returns":"حالیہ واپسی",
    "New Sale":"نئی فروخت", "Bill":"بل", "Item":"آئٹم", "Rate":"ریٹ", "Shop Name":"دکان کا نام",
    "Owner Name":"اونر کا نام", "Currency":"کرنسی", "New Owner Password":"نیا اونر پاسورڈ",
    "Leave blank to keep current":"موجودہ پاسورڈ رکھنے کے لیے خالی چھوڑیں", "Save Settings":"ترتیبات محفوظ کریں",
    "Daily Closing":"روزانہ کلوزنگ", "Close Day":"دن بند کریں", "Monthly Report":"ماہانہ رپورٹ",
    "Gross Profit":"مجموعی منافع", "Net Profit":"خالص منافع",
    "This report is generated automatically for the current month. Daily closing records are stored separately.":"یہ رپورٹ موجودہ ماہ کے لیے خودکار طور پر تیار ہوتی ہے۔ روزانہ کلوزنگ کا ریکارڈ الگ محفوظ ہوتا ہے۔",
    "Product added.":"پروڈکٹ شامل کر دیا گیا۔", "Product updated.":"پروڈکٹ اپڈیٹ کر دیا گیا۔",
    "Product not found.":"پروڈکٹ نہیں ملا۔", "Quantity must be greater than zero.":"مقدار صفر سے زیادہ ہونی چاہیے۔",
    "Cart quantity exceeds stock.":"کارٹ کی مقدار اسٹاک سے زیادہ ہے۔", "Invalid quantity / stock.":"غلط مقدار / اسٹاک۔",
    "Bill is empty.":"بل خالی ہے۔", "Invalid product, quantity or price.":"غلط پروڈکٹ، مقدار یا قیمت۔",
    "Invalid return data.":"واپسی کا ڈیٹا غلط ہے۔", "Return saved and stock adjusted.":"واپسی محفوظ کر دی گئی اور اسٹاک ایڈجسٹ کر دیا گیا۔",
    "Daily closing saved.":"روزانہ کلوزنگ محفوظ کر دی گئی۔", "Settings saved.":"ترتیبات محفوظ کر دی گئیں۔",
    "Logged out.":"لاگ آؤٹ ہو گیا۔", "Owner login required.":"اونر لاگ اِن ضروری ہے۔",
    "Product":"پروڈکٹ", "Products":"پروڈکٹس", "Qty":"مقدار", "Buying Price":"خرید قیمت",
    "Selling Price":"فروخت قیمت", "Select":"منتخب کریں", "Stock":"اسٹاک", "Search":"تلاش",
    "Clear":"صاف کریں", "Go":"جائیں", "Profit":"منافع", "Bills":"بلز", "Date":"تاریخ",
    "Description":"تفصیل", "Type":"قسم", "Amount":"رقم", "Customer (optional)":"گاہک (اختیاری)",
    "Supplier (optional)":"سپلائر (اختیاری)", "Purchase":"خریداری", "Fast Sale":"فاسٹ سیل",
    "Settings":"ترتیبات", "Management":"مینجمنٹ", "Returns":"واپسی", "Reports":"رپورٹس",
    "Backup":"بیک اپ", "Suppliers":"سپلائرز", "Expenses":"اخراجات", "Owner":"اونر", "Staff":"اسٹاف",
    "No supplier found":"کوئی سپلائر نہیں ملا", "Barcode scan failed.":"بارکوڈ اسکین نہیں ہو سکا۔",
    "Barcode not found.":"بارکوڈ نہیں ملا۔",

}

def localize_html(text):
    pairs = UI_TEXT.items() if lang()=="ur" else ((u,e) for e,u in UI_TEXT.items())
    for a,b in sorted(pairs,key=lambda x:len(x[0]),reverse=True): text=text.replace(a,b)
    return text

def hash_password(p):
    return hashlib.sha256(p.encode("utf-8")).hexdigest()

def verify_password(p, h): return secrets.compare_digest(hash_password(p), h)

@app.context_processor
def globals_ctx():
    return {"T":T, "lang":lang(), "dir":"rtl" if lang()=="ur" else "ltr", "money":money,
            "owner_logged":session.get("owner_logged",False)}

# ---------------- DB ----------------
def db():
    c = getattr(g, "_db", None)
    if c is None:
        c = g._db = sqlite3.connect(DB_NAME)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
    return c

@app.teardown_appcontext
def close_db(exc=None):
    c = getattr(g, "_db", None)
    if c: c.close()

def columns(c, table):
    return {r[1] for r in c.execute(f"PRAGMA table_info({table})").fetchall()}

def ensure_column(c, table, column, definition):
    if column not in columns(c, table):
        c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

def init_db():
    c = sqlite3.connect(DB_NAME)
    c.execute("PRAGMA foreign_keys=ON")
    c.executescript("""
    CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY, shop_name TEXT, owner_name TEXT, phone TEXT, address TEXT, language TEXT, currency TEXT);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,category TEXT,unit TEXT,buying_price REAL DEFAULT 0,selling_price REAL DEFAULT 0,current_stock REAL DEFAULT 0,min_stock REAL DEFAULT 0,barcode TEXT,notes TEXT,status TEXT DEFAULT 'active');
    CREATE TABLE IF NOT EXISTS product_price_history(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,date TEXT,old_buying REAL,new_buying REAL,old_selling REAL,new_selling REAL);
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,opening_balance REAL DEFAULT 0,notes TEXT,status TEXT DEFAULT 'active');
    CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,company TEXT,address TEXT,opening_balance REAL DEFAULT 0,notes TEXT,status TEXT DEFAULT 'active');
    CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,supplier_id INTEGER,total_amount REAL DEFAULT 0,paid_amount REAL DEFAULT 0,credit_amount REAL DEFAULT 0,due_date TEXT,notes TEXT,discount REAL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER,product_id INTEGER,quantity REAL,unit TEXT,buying_price REAL,additional_cost REAL DEFAULT 0,total REAL);
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,customer_id INTEGER,subtotal REAL DEFAULT 0,discount REAL DEFAULT 0,total_amount REAL DEFAULT 0,paid_amount REAL DEFAULT 0,credit_amount REAL DEFAULT 0,change_amount REAL DEFAULT 0,due_date TEXT,notes TEXT);
    CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,product_id INTEGER,quantity REAL,unit TEXT,selling_price REAL,historical_cost REAL,total REAL,profit REAL);
    CREATE TABLE IF NOT EXISTS customer_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER,date TEXT,type TEXT,ref_id INTEGER,amount REAL,description TEXT);
    CREATE TABLE IF NOT EXISTS supplier_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,supplier_id INTEGER,date TEXT,type TEXT,ref_id INTEGER,amount REAL,description TEXT);
    CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,category TEXT,amount REAL,description TEXT);
    CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,date TEXT,type TEXT,qty_in REAL DEFAULT 0,qty_out REAL DEFAULT 0,balance REAL DEFAULT 0,reference TEXT);
    CREATE TABLE IF NOT EXISTS returns(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,type TEXT,ref_id INTEGER,party_id INTEGER,total_amount REAL DEFAULT 0,reason TEXT,discount REAL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS return_items(id INTEGER PRIMARY KEY AUTOINCREMENT,return_id INTEGER,product_id INTEGER,quantity REAL,price REAL,total REAL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password_hash TEXT,role TEXT DEFAULT 'owner',active INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS daily_closings(id INTEGER PRIMARY KEY AUTOINCREMENT,close_date TEXT UNIQUE,closed_at TEXT,sales REAL DEFAULT 0,credit REAL DEFAULT 0,expenses REAL DEFAULT 0,profit REAL DEFAULT 0);
    CREATE INDEX IF NOT EXISTS idx_product_name ON products(name);
    CREATE INDEX IF NOT EXISTS idx_product_barcode ON products(barcode);
    CREATE INDEX IF NOT EXISTS idx_customer_name ON customers(name);
    CREATE INDEX IF NOT EXISTS idx_supplier_name ON suppliers(name);
    """)
    # Compatibility with older RetailPro files.
    for table, specs in {
        "products":[("status","TEXT DEFAULT 'active'"),("barcode","TEXT")],
        "sales":[("discount","REAL DEFAULT 0"), ("due_date","TEXT"), ("notes","TEXT")],
        "purchases":[("discount","REAL DEFAULT 0")],
        "return_items":[("total","REAL DEFAULT 0")],
        "purchase_items":[("additional_cost","REAL DEFAULT 0")],
        "sales":[("change_amount","REAL DEFAULT 0")],
    }.items():
        for col, definition in specs: ensure_column(c, table, col, definition)
    row = c.execute("SELECT * FROM settings LIMIT 1").fetchone()
    if not row:
        c.execute("INSERT INTO settings(shop_name,owner_name,phone,address,language,currency) VALUES(?,?,?,?,?,?)",
                  ("ریٹیل پرو شاپ","Shop Owner","","","ur","Rs"))
    else:
        # If an older DB has a blank language, keep Urdu as default.
        c.execute("UPDATE settings SET language=COALESCE(NULLIF(language,''),'ur') WHERE id=?", (row[0],))
    u = c.execute("SELECT id FROM users WHERE username=?", (DEFAULT_OWNER_USER,)).fetchone()
    if not u:
        c.execute("INSERT INTO users(username,password_hash,role,active) VALUES(?,?,?,1)",
                  (DEFAULT_OWNER_USER, hash_password(DEFAULT_OWNER_PASSWORD), "owner"))
    c.commit(); c.close()

init_db()

# ---------------- AUTH ----------------
def owner_required(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if not session.get("owner_logged"):
            flash("اونر لاگ اِن ضروری ہے۔" if lang()=="ur" else "Owner login required.", "warning")
            return redirect(url_for("owner_login", next=request.path))
        return fn(*a, **kw)
    return wrapper

@app.route("/owner-login", methods=["GET","POST"])
def owner_login():
    if request.method == "POST":
        username = request.form.get("username","admin").strip()
        password = request.form.get("password","")
        u = db().execute("SELECT * FROM users WHERE username=? AND role='owner' AND active=1",(username,)).fetchone()
        if u and verify_password(password, u["password_hash"]):
            session["owner_logged"] = True; session["owner_user"] = username
            return redirect(request.args.get("next") or request.form.get("next") or url_for("dashboard"))
        flash("غلط یوزرنیم یا پاسورڈ۔" if lang()=="ur" else "Invalid username or password.", "danger")
    return render("اونر لاگ اِن / Owner Login", """
    <div class="login-card">
      <div class="login-logo">RP</div><h2>RetailPro</h2>
      <p class="muted">Owner Management Login</p>
      <form method="post">
        <label>Username</label><input class="form-control mb-3" name="username" value="admin" required>
        <label>Password</label><input class="form-control mb-3" type="password" name="password" required autofocus>
        <input type="hidden" name="next" value="{{ request.args.get('next','') }}">
        <button class="btn btn-primary w-100 btn-lg">🔐 Login</button>
      </form>
      <div class="small muted mt-3">Default first login: admin / 1234 — change it in Settings.</div>
    </div>""")

@app.route("/logout")
def logout():
    session.pop("owner_logged",None); session.pop("owner_user",None)
    flash("لاگ آؤٹ ہوگیا۔" if lang()=="ur" else "Logged out.", "success")
    return redirect(url_for("sales"))

@app.route("/language/<lang_code>")
def language(lang_code):
    if lang_code in ("ur","en"): session["lang"] = lang_code
    return redirect(request.referrer or url_for("sales"))

# ---------------- UI ----------------
BASE = """
<!doctype html><html lang="{{lang}}" dir="{{dir}}"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{{T('title')}}{% if title %} — {{title}}{% endif %}</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
:root{--p:#5b21b6;--p2:#7c3aed;--cyan:#0891b2;--green:#059669;--danger:#dc2626;--ink:#172033;--glass:rgba(255,255,255,.94);--pink:#ec4899;--orange:#f97316}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;color:var(--ink);font-family:system-ui,-apple-system,"Noto Sans Arabic",sans-serif;background:radial-gradient(circle at 8% 8%,#fef3c7 0,transparent 22%),radial-gradient(circle at 92% 18%,#fce7f3 0,transparent 24%),radial-gradient(circle at 18% 88%,#cffafe 0,transparent 25%),linear-gradient(135deg,#eef2ff 0,#faf5ff 45%,#ecfeff 100%);min-height:100vh;padding-bottom:78px}
.navbar{background:linear-gradient(120deg,#312e81,#7c3aed,#db2777,#0891b2);background-size:220% 220%;animation:gradientShift 9s ease infinite;box-shadow:0 8px 28px #312e8133}.brand{font-weight:900;letter-spacing:.2px}.container-main{max-width:1180px;margin:auto;padding:14px}.page-title{font-weight:900;margin:6px 0 14px;letter-spacing:-.3px}.card{border:1px solid #ffffffaa;border-radius:20px;background:var(--glass);box-shadow:0 10px 30px #312e8114;backdrop-filter:blur(10px);animation:cardIn .35s ease both}.btn{border-radius:12px;font-weight:700;transition:transform .16s ease,box-shadow .16s ease}.btn:hover{transform:translateY(-1px);box-shadow:0 7px 18px #312e8120}.form-control,.form-select{border-radius:12px;padding:.72rem .85rem;border:1px solid #dbe1ee;background:#ffffffdd}.form-control:focus,.form-select:focus{border-color:#8b5cf6;box-shadow:0 0 0 .2rem #8b5cf622}.stat{padding:16px;border-radius:18px;background:linear-gradient(135deg,#fff,#eef2ff);height:100%;border:1px solid #ffffff}.stat h3{font-weight:900}.quick{min-height:86px}.table{vertical-align:middle}.table thead th{white-space:nowrap}.table-responsive{border-radius:16px}.bottom{position:fixed;bottom:0;left:0;right:0;background:#ffffffed;backdrop-filter:blur(12px);border-top:1px solid #e5e7eb;z-index:50;display:flex;justify-content:space-around;padding:8px 4px}.bottom a{font-size:11px;text-decoration:none;color:#374151;text-align:center}.bottom i{display:block;font-size:20px}.bottom .sale{color:#059669}.badge-soft{background:linear-gradient(135deg,#ede9fe,#fce7f3);color:#5b21b6;border:1px solid #ddd6fe;padding:.45rem .7rem;border-radius:999px}.search-results{position:relative;z-index:20;margin-top:8px}.search-results button{width:100%;text-align:start;border:1px solid #e5e7eb;border-radius:12px;background:#fff;padding:11px;margin-bottom:6px;transition:all .16s ease}.search-results button:hover{border-color:#8b5cf6;background:#f5f3ff;transform:translateX(2px)}.search-results form{animation:resultIn .18s ease both}.scan-btn{white-space:nowrap}.cart-total{font-size:1.25rem;font-weight:900}.sticky-card{position:sticky;top:12px}.login-card{max-width:430px;margin:8vh auto;background:#fff;padding:28px;border-radius:28px;box-shadow:0 25px 70px #312e8130;text-align:center}.login-logo{width:74px;height:74px;border-radius:22px;background:linear-gradient(135deg,#4f46e5,#a855f7);color:#fff;display:grid;place-items:center;font-size:28px;font-weight:900;margin:0 auto 14px}.muted{color:#64748b}.management-lock{border:1px dashed #c4b5fd;background:#f5f3ff;border-radius:16px;padding:12px}.invoice{background:#fff;padding:24px;border-radius:18px}.no-print{}
@keyframes gradientShift{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}@keyframes cardIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}@keyframes resultIn{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}
@media(max-width:576px){.container-main{padding:10px}.card{border-radius:16px}.btn-lg{font-size:1rem}.table{font-size:.88rem}.sticky-card{position:static}.desktop-hide{display:none}.form-label{font-weight:700}.quick{min-height:74px}} 
@media print{body{background:#fff;padding:0}.navbar,.bottom,.back,.no-print{display:none!important}.container-main{max-width:800px}.card,.invoice{box-shadow:none;border:0}}
</style></head><body>
<nav class="navbar navbar-dark"><div class="container-fluid px-3"><a class="navbar-brand brand" href="{{url_for('sales')}}">🛒 RetailPro</a><div class="d-flex gap-2 align-items-center"><a class="btn btn-sm btn-light" href="{{url_for('language', lang_code=('en' if lang=='ur' else 'ur'))}}">{{'EN' if lang=='ur' else 'اردو'}}</a>{% if owner_logged %}<span class="badge bg-light text-dark">Owner</span><a class="btn btn-sm btn-outline-light" href="{{url_for('logout')}}">⎋</a>{% else %}<a class="btn btn-sm btn-outline-light" href="{{url_for('owner_login')}}">🔐</a>{% endif %}</div></div></nav>
<main class="container-main">{% with msgs=get_flashed_messages(with_categories=true) %}{% for cat,msg in msgs %}<div class="alert alert-{{cat}} py-2">{{msg}}</div>{% endfor %}{% endwith %}
{% if title %}<a class="back" href="javascript:history.back()">← {{T('back')}}</a><h2 class="page-title">{{title}}</h2>{% endif %}{{body|safe}}</main>
<div class="bottom"><a class="sale" href="{{url_for('sales')}}"><i class="bi bi-cart-plus-fill"></i>{{T('sales')}}</a>{% if owner_logged %}<a href="{{url_for('dashboard')}}"><i class="bi bi-speedometer2"></i>{{T('dashboard')}}</a><a href="{{url_for('products')}}"><i class="bi bi-box-seam"></i>{{T('products')}}</a><a href="{{url_for('customers')}}"><i class="bi bi-people"></i>{{T('customers')}}</a><a href="{{url_for('management')}}"><i class="bi bi-grid-fill"></i>{{T('management')}}</a>{% else %}<a href="{{url_for('owner_login')}}"><i class="bi bi-lock-fill"></i>Owner</a>{% endif %}</div>
<script>function money(n){return 'Rs '+Number(n||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}</script>
{% block extra %}{% endblock %}</body></html>"""

def render(title, body, **ctx):
    rendered_body = localize_html(render_template_string(body, **ctx))
    if " / " in title:
        title = title.split(" / ",1)[0] if lang()=="ur" else title.split(" / ",1)[1]
    title = localize_html(title)
    return render_template_string(BASE, title=title, body=rendered_body, **ctx)

# ---------------- SALES ----------------
def get_sale_cart(): return session.get("sale_cart", [])
def set_sale_cart(cart): session["sale_cart"] = cart; session.modified=True
def get_purchase_cart(): return session.get("purchase_cart", [])
def set_purchase_cart(cart): session["purchase_cart"] = cart; session.modified=True

def cart_totals(cart): return sum(num(x["qty"])*num(x["price"])+num(x.get("extra_cost",0)) for x in cart)

@app.route("/sales", methods=["GET","POST"])
@app.route("/sales/add", methods=["GET","POST"])
def sales():
    c=db()
    if request.method=="POST":
        pid=int(request.form.get("product_id",0)); qty=num(request.form.get("quantity"))
        p=c.execute("SELECT * FROM products WHERE id=? AND status='active'",(pid,)).fetchone()
        if not p: flash("Product not found.","danger")
        elif qty<=0: flash("Quantity must be greater than zero.","danger")
        elif num(p["current_stock"]) < qty: flash(f"Not enough stock. Available: {p['current_stock']}","danger")
        else:
            cart=get_sale_cart(); found=False
            for x in cart:
                if x["product_id"]==pid:
                    if num(x["qty"])+qty <= num(p["current_stock"]): x["qty"]=num(x["qty"])+qty
                    else: flash("Cart quantity exceeds stock.","warning")
                    found=True; break
            if not found: cart.append({"product_id":pid,"name":p["name"],"barcode":p["barcode"] or "","unit":p["unit"],"price":num(p["selling_price"]),"cost":num(p["buying_price"]),"qty":qty,"stock":num(p["current_stock"])})
            set_sale_cart(cart); flash(f"{p['name']} cart میں شامل ہوگیا۔","success")
        return redirect(url_for("sales"))
    cart=get_sale_cart(); customers=c.execute("SELECT * FROM customers WHERE status='active' ORDER BY name").fetchall()
    subtotal=cart_totals(cart)
    return render("فاسٹ سیل / Fast Sale", """
    <div class="row g-3"><div class="col-lg-8">
      <div class="card p-3 mb-3">
        <div class="d-flex gap-2"><input id="prodSearch" class="form-control" placeholder="{{T('search')}}"><button class="btn btn-dark scan-btn" onclick="scanBarcode()">📷 {{T('scan')}}</button></div>
        <div id="prodResults" class="search-results"></div>
        <div class="small muted mt-2">نام یا بارکوڈ لکھیں؛ یا اسکین کریں۔ قیمت، موجودہ اسٹاک اور لاگت خودکار آئے گی۔</div>
      </div>
      <div class="card p-2"><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Total</th><th></th></tr></thead><tbody>
      {% for x in cart %}<tr><td><b>{{x.name}}</b><br><small class="muted">{{x.barcode}}</small></td><td>{{money(x.price)}}</td><td><form class="d-flex gap-1" method="post" action="{{url_for('sales_cart_qty')}}"><input type="hidden" name="product_id" value="{{x.product_id}}"><input class="form-control form-control-sm" style="width:80px" type="number" step="0.01" name="quantity" value="{{x.qty}}"><button class="btn btn-sm btn-outline-primary">✓</button></form></td><td><b>{{money(x.qty*x.price)}}</b></td><td><a class="btn btn-sm btn-outline-danger" href="{{url_for('sales_cart_remove',pid=x.product_id)}}">×</a></td></tr>{% else %}<tr><td colspan="5" class="text-center muted py-4">Scan/search a product to start the bill.</td></tr>{% endfor %}
      </tbody></table></div></div>
    </div><div class="col-lg-4"><div class="card p-3 sticky-card">
      <label class="form-label">{{T('customer')}}</label><input id="custSearch" class="form-control" placeholder="گاہک کا نام / فون"><div id="custResults" class="search-results"></div>
      <form method="post" action="{{url_for('sales_checkout')}}" class="mt-2">
        <input type="hidden" id="customer_id" name="customer_id"><label class="form-label">Customer Name</label><input id="customerName" name="customer_name" class="form-control mb-2" placeholder="Name for credit sale"><label class="form-label">Phone</label><input name="customer_phone" class="form-control mb-2" placeholder="Optional phone"><div id="selectedCustomer" class="badge badge-soft mb-2">{{T('walkin')}}</div>
        <label class="form-label">{{T('discount')}} (Rs)</label><input class="form-control mb-2" name="discount" id="discount" type="number" step="0.01" value="0">
        <label class="form-label">{{T('paid')}}</label><input class="form-control mb-2" name="paid" id="paid" type="number" step="0.01" value="{{subtotal}}">
        <label class="form-label">Due Date (اگر ادھار ہو)</label><input class="form-control mb-2" type="date" name="due_date">
        <label class="form-label">Notes</label><input class="form-control mb-3" name="notes">
        <div class="d-flex justify-content-between"><span>Subtotal</span><b id="subtotal">{{money(subtotal)}}</b></div><div class="d-flex justify-content-between"><span>Discount</span><b id="discshow">Rs 0.00</b></div><hr><div class="d-flex justify-content-between cart-total"><span>Total</span><span id="grand">{{money(subtotal)}}</span></div><div class="d-flex justify-content-between"><span>Change</span><b id="change">Rs 0.00</b></div><div class="d-flex justify-content-between"><span>Credit</span><b id="credit">Rs 0.00</b></div>
        <button class="btn btn-success btn-lg w-100 mt-3" {% if not cart %}disabled{% endif %}>🧾 {{T('checkout')}}</button>
      </form><a class="btn btn-outline-danger w-100 mt-2" href="{{url_for('sales_clear')}}">Clear Bill</a>
    </div></div></div>
    <script>
    const ps=document.getElementById('prodSearch'), pr=document.getElementById('prodResults');
    let timer; ps.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>productSearch(ps.value),180)});
    async function productSearch(q){if(!q.trim()){pr.innerHTML='';return} let r=await fetch('{{url_for('api_products')}}?q='+encodeURIComponent(q));let a=await r.json();pr.innerHTML=a.map(p=>`<form method="post" action="{{url_for('sales')}}" class="d-block"><input type="hidden" name="product_id" value="${p.id}"><div class="input-group"><button class="btn btn-light flex-grow-1" type="submit"><b>${p.name}</b> — ${money(p.selling_price)} — Stock ${p.current_stock}<small class="d-block">${p.barcode||''}</small></button><input name="quantity" value="1" type="number" step="0.01" style="max-width:75px" class="form-control"><button class="btn btn-success">+</button></div></form>`).join('')||'<div class="p-2 muted">No product found</div>'}
    const cs=document.getElementById('custSearch'), cr=document.getElementById('custResults');let ct;cs.addEventListener('input',()=>{clearTimeout(ct);ct=setTimeout(()=>customerSearch(cs.value),180)});
    async function customerSearch(q){if(!q.trim()){cr.innerHTML='';return}let r=await fetch('{{url_for('api_customers')}}?q='+encodeURIComponent(q));let a=await r.json();cr.innerHTML=a.map(x=>`<button type="button" onclick="chooseCustomer(${x.id},${JSON.stringify(x.name)})">${x.name} — ${x.phone||''}</button>`).join('')||'<div class="p-2 muted">No customer found</div>'}
    function chooseCustomer(id,name){document.getElementById('customer_id').value=id;document.getElementById('customerName').value=name;document.getElementById('selectedCustomer').textContent=name;cr.innerHTML='';cs.value=name}
    function scanBarcode(){if(!('BarcodeDetector' in window)){alert('آپ کے براؤزر میں BarcodeDetector دستیاب نہیں۔ Chrome کے تازہ ورژن میں کوشش کریں، یا اوپر بارکوڈ ٹائپ کریں۔');return} const input=document.createElement('input');input.type='file';input.accept='image/*';input.capture='environment';input.onchange=async()=>{const img=document.createElement('img');img.src=URL.createObjectURL(input.files[0]);img.onload=async()=>{try{const d=new BarcodeDetector();const codes=await d.detect(img);if(codes[0]){ps.value=codes[0].rawValue;productSearch(ps.value)}}catch(e){alert('Barcode scan failed.')}}};input.click()}
    function recalc(){let s={{subtotal}};let d=Math.max(0,Number(document.getElementById('discount').value||0));d=Math.min(d,s);let total=s-d;document.getElementById('discshow').textContent=money(d);document.getElementById('grand').textContent=money(total);let paid=document.getElementById('paid');if(!paid.dataset.touched)paid.value=total.toFixed(2);let pv=Math.max(0,Number(paid.value||0));document.getElementById('change').textContent=money(Math.max(0,pv-total));document.getElementById('credit').textContent=money(Math.max(0,total-pv))}document.getElementById('discount').addEventListener('input',recalc);document.getElementById('paid').addEventListener('input',e=>{e.target.dataset.touched='1';recalc()});recalc();
    </script>""", cart=cart, customers=customers, subtotal=subtotal)

@app.post("/sales/cart/qty")
def sales_cart_qty():
    pid=int(request.form.get("product_id",0)); qty=num(request.form.get("quantity")); c=db();p=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
    if not p or qty<=0 or qty>num(p["current_stock"]): flash("Invalid quantity / stock.","danger")
    else:
        cart=[x for x in get_sale_cart() if x["product_id"]!=pid]; x={"product_id":pid,"name":p["name"],"barcode":p["barcode"] or "","unit":p["unit"],"price":num(p["selling_price"]),"cost":num(p["buying_price"]),"qty":qty,"stock":num(p["current_stock"])};cart.append(x);set_sale_cart(cart)
    return redirect(url_for("sales"))

@app.get("/sales/cart/remove/<int:pid>")
def sales_cart_remove(pid): set_sale_cart([x for x in get_sale_cart() if x["product_id"]!=pid]); return redirect(url_for("sales"))
@app.get("/sales/cart/clear")
def sales_clear(): set_sale_cart([]); return redirect(url_for("sales"))

@app.post("/sales/checkout")
def sales_checkout():
    cart=get_sale_cart()
    if not cart: flash("Bill is empty.","warning"); return redirect(url_for("sales"))
    c=db(); subtotal=cart_totals(cart); discount=min(max(0,num(request.form.get("discount"))),subtotal)
    total=subtotal-discount; paid=max(0,num(request.form.get("paid"))); change=max(0,paid-total); credit=max(0,total-paid)
    cid=request.form.get("customer_id") or None; cid=int(cid) if cid and cid.isdigit() else None
    customer_name=request.form.get("customer_name","").strip(); customer_phone=request.form.get("customer_phone","").strip()
    try:
        c.execute("BEGIN")
        if credit>0 and not cid:
            if not customer_name: raise ValueError("Credit sale requires a customer name.")
            ex=c.execute("SELECT id FROM customers WHERE status='active' AND lower(name)=lower(?) LIMIT 1",(customer_name,)).fetchone()
            if ex: cid=ex[0]
            else:
                curc=c.execute("INSERT INTO customers(name,phone,status) VALUES(?,?,?)",(customer_name,customer_phone,"active")); cid=curc.lastrowid
        checked=[]
        for x in cart:
            p=c.execute("SELECT * FROM products WHERE id=? AND status='active'",(x["product_id"],)).fetchone()
            if not p or num(p["current_stock"])<num(x["qty"]): raise ValueError(f"Stock changed for {x['name']}")
            price=num(p["selling_price"]); cost=num(p["buying_price"]); qty=num(x["qty"]); line=qty*price; checked.append((p,price,cost,qty,line))
        cur=c.execute("INSERT INTO sales(date,customer_id,subtotal,discount,total_amount,paid_amount,credit_amount,change_amount,due_date,notes) VALUES(?,?,?,?,?,?,?,?,?,?)",(now(),cid,subtotal,discount,total,paid,credit,change,request.form.get("due_date") or None,request.form.get("notes","")));sid=cur.lastrowid
        for p,price,cost,qty,line in checked:
            alloc=discount*(line/subtotal) if subtotal else 0; net=line-alloc; profit=net-(cost*qty)
            c.execute("INSERT INTO sale_items(sale_id,product_id,quantity,unit,selling_price,historical_cost,total,profit) VALUES(?,?,?,?,?,?,?,?)",(sid,p["id"],qty,p["unit"],price,cost,net,profit))
            ns=num(p["current_stock"])-qty;c.execute("UPDATE products SET current_stock=? WHERE id=?",(ns,p["id"]))
            c.execute("INSERT INTO stock_movements(product_id,date,type,qty_in,qty_out,balance,reference) VALUES(?,?,?,?,?,?,?)",(p["id"],now(),"sale",0,qty,ns,f"Sale #{sid}"))
        if cid:
            if total:c.execute("INSERT INTO customer_transactions(customer_id,date,type,ref_id,amount,description) VALUES(?,?,?,?,?,?)",(cid,now(),"sale",sid,total,"Sale"))
            if paid and paid<=total:c.execute("INSERT INTO customer_transactions(customer_id,date,type,ref_id,amount,description) VALUES(?,?,?,?,?,?)",(cid,now(),"payment",sid,paid,"Payment with sale"))
        c.commit();set_sale_cart([]);flash(f"Sale #{sid} completed. Total {money(total)} | Paid {money(paid)} | Change {money(change)} | Credit {money(credit)}","success");return redirect(url_for("sale_invoice",sid=sid))
    except Exception as e:c.rollback();flash(str(e),"danger");return redirect(url_for("sales"))

# ---------------- PURCHASES ----------------
@app.route("/purchases",methods=["GET","POST"])
@app.route("/purchases/add",methods=["GET","POST"])
@owner_required
def purchases():
    c=db()
    if request.method=="POST":
        pid=int(request.form.get("product_id",0));qty=num(request.form.get("quantity"));price=num(request.form.get("buy_price"));extra=num(request.form.get("extra_cost"));p=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
        if not p or qty<=0 or price<0: flash("Invalid product, quantity or price.","danger")
        else:
            cart=get_purchase_cart();found=False
            for x in cart:
                if x["product_id"]==pid:x["qty"]=num(x["qty"])+qty;x["price"]=price;x["extra_cost"]=num(x.get("extra_cost",0))+extra;found=True;break
            if not found:cart.append({"product_id":pid,"name":p["name"],"barcode":p["barcode"] or "","unit":p["unit"],"qty":qty,"price":price,"extra_cost":extra})
            set_purchase_cart(cart);flash(f"{p['name']} خریداری کارٹ میں شامل ہوگیا۔","success")
        return redirect(url_for("purchases"))
    suppliers=c.execute("SELECT * FROM suppliers WHERE status='active' ORDER BY name").fetchall();cart=get_purchase_cart();subtotal=cart_totals(cart)
    return render("خریداری / Purchase", """
    <div class="row g-3"><div class="col-lg-8"><div class="card p-3 mb-3"><div class="input-group"><input id="ps" class="form-control" autocomplete="off" placeholder="پروڈکٹ نام یا بارکوڈ تلاش کریں"><button type="button" class="btn btn-primary" onclick="psearch()">🔎 Search</button><button type="button" class="btn btn-dark scan-btn" onclick="scanPurchaseBarcode()">📷 Scan</button></div><div id="pr" class="search-results"></div><div class="small muted mt-2">نام یا بارکوڈ سے پروڈکٹ تلاش کریں، پھر <b>＋ Select</b> دبائیں۔</div></div>
    <div class="card p-2"><div class="table-responsive"><table class="table"><thead><tr><th>Product</th><th>Buy Price</th><th>Qty</th><th>Extra Cost</th><th>Total</th><th></th></tr></thead><tbody>{% for x in cart %}<tr><td>{{x.name}}<br><small>{{x.barcode}}</small></td><td>{{money(x.price)}}</td><td>{{x.qty}}</td><td>{{money(x.extra_cost or 0)}}</td><td>{{money(x.qty*x.price+(x.extra_cost or 0))}}</td><td><a class="btn btn-sm btn-outline-danger" href="{{url_for('purchase_cart_remove',pid=x.product_id)}}">×</a></td></tr>{% else %}<tr><td colspan="6" class="text-center muted">Add products.</td></tr>{% endfor %}</tbody></table></div></div></div>
    <div class="col-lg-4"><div class="card p-3 sticky-card"><label class="form-label">Supplier Search</label><input id="ss" class="form-control" autocomplete="off" placeholder="سپلائر کا نام، فون یا کمپنی لکھیں"><div id="sr" class="search-results"></div><form method="post" action="{{url_for('purchase_checkout')}}"><input type="hidden" name="supplier_id" id="supplier_id"><div id="selSup" class="badge badge-soft mt-2">No supplier selected</div><label class="form-label mt-2">Purchase Discount (Rs)</label><input name="discount" id="pd" class="form-control mb-2" type="number" step="0.01" value="0"><label class="form-label">Paid</label><input name="paid" class="form-control mb-2" type="number" step="0.01" value="{{subtotal}}"><label class="form-label">Due Date</label><input name="due_date" class="form-control mb-2" type="date"><label class="form-label">Notes</label><input name="notes" class="form-control mb-3"><div class="d-flex justify-content-between"><b>Subtotal</b><b>{{money(subtotal)}}</b></div><button class="btn btn-primary btn-lg w-100 mt-3" {% if not cart %}disabled{% endif %}>💾 Save Purchase & Stock In</button></form><a class="btn btn-outline-danger w-100 mt-2" href="{{url_for('purchase_clear')}}">Clear</a></div></div></div>
    <script>
    const purchaseProductSearch=document.getElementById('ps'), purchaseProductResults=document.getElementById('pr');
    const supplierSearch=document.getElementById('ss'), supplierResults=document.getElementById('sr');
    const supplierIdInput=document.getElementById('supplier_id'), selectedSupplier=document.getElementById('selSup');
    let productTimer,supplierTimer;
    async function psearch(q){
      q=(q===undefined?purchaseProductSearch.value:q).trim();
      if(!q){purchaseProductResults.innerHTML='';return;}
      try{
        const r=await fetch('{{url_for('api_products')}}?q='+encodeURIComponent(q));
        const a=await r.json();
        purchaseProductResults.innerHTML=a.map(p=>`<form method="post" action="{{url_for('purchases')}}" class="mb-2"><input type="hidden" name="product_id" value="${p.id}"><div class="card p-2"><div class="d-flex gap-2 align-items-center flex-wrap"><button class="btn btn-success" type="submit">＋ Select</button><div class="flex-grow-1"><b>${p.name}</b><div class="small muted">Barcode: ${p.barcode||'—'} · Current buy: ${money(p.buying_price)}</div></div><input aria-label="Buy price" class="form-control" name="buy_price" type="number" step="0.01" value="${p.buying_price}" style="max-width:120px"><input aria-label="Quantity" class="form-control" name="quantity" type="number" step="0.01" min="0.01" value="1" style="max-width:90px"><input aria-label="Extra cost" class="form-control" name="extra_cost" type="number" step="0.01" min="0" value="0" placeholder="Extra cost" style="max-width:120px"></div></div></form>`).join('')||'<div class="p-2 muted">No product found</div>';
      }catch(e){purchaseProductResults.innerHTML='<div class="alert alert-danger py-2">Product search failed. Please try again.</div>';}
    }
    purchaseProductSearch.addEventListener('input',()=>{clearTimeout(productTimer);productTimer=setTimeout(()=>psearch(),180)});
    async function supplierSearchRun(q){
      q=(q===undefined?supplierSearch.value:q).trim();
      if(!q){supplierResults.innerHTML='';return;}
      try{
        const r=await fetch('{{url_for('api_suppliers')}}?q='+encodeURIComponent(q));
        const a=await r.json();
        supplierResults.innerHTML=a.map(x=>`<button type="button" onclick='chooseSup(${x.id},${JSON.stringify(x.name)})'><b>${x.name}</b> — ${x.phone||''}${x.company?' · '+x.company:''}</button>`).join('')||'<div class="p-2 muted">No supplier found</div>';
      }catch(e){supplierResults.innerHTML='<div class="alert alert-danger py-2">Supplier search failed. Please try again.</div>';}
    }
    supplierSearch.addEventListener('input',()=>{clearTimeout(supplierTimer);supplierTimer=setTimeout(()=>supplierSearchRun(),180)});
    function chooseSup(id,n){supplierIdInput.value=String(id);selectedSupplier.textContent=n;selectedSupplier.className='badge badge-soft mt-2';supplierResults.innerHTML='';supplierSearch.value=n;}
    function scanPurchaseBarcode(){
      if(!('BarcodeDetector' in window)){alert('آپ کے براؤزر میں BarcodeDetector دستیاب نہیں۔ Chrome کے تازہ ورژن میں کوشش کریں، یا بارکوڈ اوپر ٹائپ کریں۔');return;}
      const input=document.createElement('input');input.type='file';input.accept='image/*';input.capture='environment';
      input.onchange=async()=>{if(!input.files[0])return;const img=document.createElement('img');img.src=URL.createObjectURL(input.files[0]);img.onload=async()=>{try{const d=new BarcodeDetector();const codes=await d.detect(img);if(codes[0]){purchaseProductSearch.value=codes[0].rawValue;psearch(codes[0].rawValue)}else alert('Barcode not found.');}catch(e){alert('Barcode scan failed.');}finally{URL.revokeObjectURL(img.src);}}};input.click();
    }
    </script>
    """,cart=cart,subtotal=subtotal)

@app.post("/purchases/checkout")
@owner_required
def purchase_checkout():
    cart=get_purchase_cart()
    if not cart:return redirect(url_for("purchases"))
    c=db();subtotal=cart_totals(cart);discount=min(max(0,num(request.form.get("discount"))),subtotal);total=subtotal-discount;paid=min(max(0,num(request.form.get("paid"))),total);credit=total-paid;sid=request.form.get("supplier_id") or None;sid=int(sid) if sid and sid.isdigit() else None
    try:
        c.execute("BEGIN");cur=c.execute("INSERT INTO purchases(date,supplier_id,total_amount,paid_amount,credit_amount,due_date,notes,discount) VALUES(?,?,?,?,?,?,?,?)",(now(),sid,total,paid,credit,request.form.get("due_date") or None,request.form.get("notes",""),discount));pur=cur.lastrowid
        for x in cart:
            p=c.execute("SELECT * FROM products WHERE id=?",(x["product_id"],)).fetchone();qty=num(x["qty"]);price=num(x["price"]);extra=num(x.get("extra_cost",0));line=qty*price+extra;alloc=discount*(line/subtotal) if subtotal else 0;net=line-alloc;landed=max(0,(net/qty) if qty else price)
            old_buy=num(p["buying_price"]);old_sell=num(p["selling_price"]);c.execute("INSERT INTO purchase_items(purchase_id,product_id,quantity,unit,buying_price,additional_cost,total) VALUES(?,?,?,?,?,?,?)",(pur,p["id"],qty,p["unit"],landed,extra,net));ns=num(p["current_stock"])+qty
            # New purchase price becomes current buying price. Keep selling price unless it was zero.
            new_sell=old_sell if old_sell>0 else price
            c.execute("UPDATE products SET current_stock=?,buying_price=?,selling_price=? WHERE id=?",(ns,landed,new_sell,p["id"]))
            c.execute("INSERT INTO product_price_history(product_id,date,old_buying,new_buying,old_selling,new_selling) VALUES(?,?,?,?,?,?)",(p["id"],now(),old_buy,landed,old_sell,new_sell))
            c.execute("INSERT INTO stock_movements(product_id,date,type,qty_in,qty_out,balance,reference) VALUES(?,?,?,?,?,?,?)",(p["id"],now(),"purchase",qty,0,ns,f"Purchase #{pur}"))
        if sid:
            if total:c.execute("INSERT INTO supplier_transactions(supplier_id,date,type,ref_id,amount,description) VALUES(?,?,?,?,?,?)",(sid,now(),"purchase",pur,total,"Purchase"))
            if paid:c.execute("INSERT INTO supplier_transactions(supplier_id,date,type,ref_id,amount,description) VALUES(?,?,?,?,?,?)",(sid,now(),"payment",pur,paid,"Payment with purchase"))
        c.commit();set_purchase_cart([]);flash(f"Purchase #{pur} saved. Stock increased.","success");return redirect(url_for("purchase_view",pid=pur))
    except Exception as e:c.rollback();flash(str(e),"danger");return redirect(url_for("purchases"))

@app.get("/purchases/cart/remove/<int:pid>")
@owner_required
def purchase_cart_remove(pid):set_purchase_cart([x for x in get_purchase_cart() if x["product_id"]!=pid]);return redirect(url_for("purchases"))
@app.get("/purchases/cart/clear")
@owner_required
def purchase_clear():set_purchase_cart([]);return redirect(url_for("purchases"))

@app.get("/purchase/<int:pid>")
@owner_required
def purchase_view(pid):
    c=db();p=c.execute("SELECT p.*,s.name supplier_name FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id WHERE p.id=?",(pid,)).fetchone();items=c.execute("SELECT i.*,p.name FROM purchase_items i JOIN products p ON p.id=i.product_id WHERE i.purchase_id=?",(pid,)).fetchall()
    if not p:return redirect(url_for("purchases"))
    return render(f"Purchase #{pid}","""<div class="card p-3"><p><b>Supplier:</b> {{p.supplier_name or 'Walk-in supplier'}}</p><div class="table-responsive"><table class="table"><tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr>{% for x in items %}<tr><td>{{x.name}}</td><td>{{x.quantity}}</td><td>{{money(x.buying_price)}}</td><td>{{money(x.total)}}</td></tr>{% endfor %}</table></div><hr><div class="d-flex justify-content-between"><b>Discount</b><b>{{money(p.discount)}}</b></div><div class="d-flex justify-content-between"><b>Total</b><b>{{money(p.total_amount)}}</b></div><div class="d-flex justify-content-between"><b>Paid</b><b>{{money(p.paid_amount)}}</b></div><div class="d-flex justify-content-between"><b>Credit</b><b>{{money(p.credit_amount)}}</b></div></div>""",p=p,items=items)

# ---------------- SEARCH APIs ----------------
@app.get("/api/products")
def api_products():
    q=request.args.get("q","").strip();c=db();
    if q:
        rows=c.execute("SELECT id,name,barcode,unit,buying_price,selling_price,current_stock FROM products WHERE status='active' AND (name LIKE ? OR barcode LIKE ? OR category LIKE ?) ORDER BY CASE WHEN barcode=? THEN 0 WHEN name=? THEN 1 ELSE 2 END,name LIMIT 30",(f"%{q}%",f"%{q}%",f"%{q}%",q,q)).fetchall()
    else: rows=c.execute("SELECT id,name,barcode,unit,buying_price,selling_price,current_stock FROM products WHERE status='active' ORDER BY name LIMIT 30").fetchall()
    return jsonify([dict(x) for x in rows])
@app.get("/api/customers")
def api_customers():
    q=request.args.get("q","").strip();rows=db().execute("SELECT id,name,phone FROM customers WHERE status='active' AND (name LIKE ? OR phone LIKE ?) ORDER BY name LIMIT 20",(f"%{q}%",f"%{q}%")).fetchall();return jsonify([dict(x) for x in rows])
@app.get("/api/suppliers")
@owner_required
def api_suppliers():
    q=request.args.get("q","").strip();rows=db().execute("SELECT id,name,phone,company FROM suppliers WHERE status='active' AND (name LIKE ? OR phone LIKE ? OR company LIKE ?) ORDER BY name LIMIT 20",(f"%{q}%",f"%{q}%",f"%{q}%")).fetchall();return jsonify([dict(x) for x in rows])

# ---------------- DASHBOARD / MANAGEMENT ----------------
@app.get("/")
@owner_required
def dashboard():
    c=db(); d=today()
    sales=num(c.execute("SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE date LIKE ?",(d+"%",)).fetchone()[0])
    gross=num(c.execute("SELECT COALESCE(SUM(profit),0) FROM sale_items i JOIN sales s ON s.id=i.sale_id WHERE s.date LIKE ?",(d+"%",)).fetchone()[0])
    expenses_today=num(c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date LIKE ?",(d+"%",)).fetchone()[0])
    profit=gross-expenses_today
    stock_value=num(c.execute("SELECT COALESCE(SUM(current_stock*buying_price),0) FROM products WHERE status='active'").fetchone()[0])
    receivable=sum(balance_for("customer",r[0]) for r in c.execute("SELECT id FROM customers WHERE status='active'").fetchall())
    payable=sum(balance_for("supplier",r[0]) for r in c.execute("SELECT id FROM suppliers WHERE status='active'").fetchall())
    pc=c.execute("SELECT COUNT(*) FROM products WHERE status='active'").fetchone()[0]; cc=c.execute("SELECT COUNT(*) FROM customers WHERE status='active'").fetchone()[0]; sc=c.execute("SELECT COUNT(*) FROM suppliers WHERE status='active'").fetchone()[0]
    low=c.execute("SELECT * FROM products WHERE status='active' AND current_stock<=min_stock ORDER BY current_stock").fetchall()
    return render("Dashboard", """<div class="row g-2 mb-3">{% for label,val,cls in [("Today's Sales",sales,'primary'),("Today's Profit",profit,'success'),("Stock Value",stock_value,'info'),("Receivable",receivable,'warning'),("Payable",payable,'danger') ,("Expenses",expenses_today,'secondary')] %}<div class="col-6 col-lg-2"><div class="stat"><small>{{label}}</small><h5 class="text-{{cls}}">{{money(val)}}</h5></div></div>{% endfor %}</div><div class="row g-2 mb-3"><div class="col-4"><div class="stat"><small>Products</small><h3>{{pc}}</h3></div></div><div class="col-4"><div class="stat"><small>Customers</small><h3>{{cc}}</h3></div></div><div class="col-4"><div class="stat"><small>Suppliers</small><h3>{{sc}}</h3></div></div></div><div class="row g-2"><div class="col-6 col-md-3"><a href="{{url_for('products')}}" class="card quick p-3 text-decoration-none">📦 <b>Products</b></a></div><div class="col-6 col-md-3"><a href="{{url_for('purchases')}}" class="card quick p-3 text-decoration-none">🚚 <b>Purchase</b></a></div><div class="col-6 col-md-3"><a href="{{url_for('returns')}}" class="card quick p-3 text-decoration-none">↩ <b>Returns</b></a></div><div class="col-6 col-md-3"><a href="{{url_for('daily_closing')}}" class="card quick p-3 text-decoration-none">🌙 <b>Daily Closing</b></a></div></div>{% if low %}<div class="card p-3 mt-3 border border-danger"><h5 class="text-danger">⚠ Low Stock</h5>{% for p in low %}<div>{{p.name}} — {{p.current_stock}}</div>{% endfor %}</div>{% endif %}""",sales=sales,profit=profit,stock_value=stock_value,receivable=receivable,payable=payable,expenses_today=expenses_today,pc=pc,cc=cc,sc=sc,low=low)

@app.get("/management")
@owner_required
def management():
    return render("مینجمنٹ / Management","""<div class="management-lock mb-3">🔐 <b>Owner Only:</b> Products, customers, suppliers, purchases, returns, expenses, reports and settings are protected. Staff can use the Sales screen without owner login.</div><div class="row g-2">{% for href,icon,text in [(url_for('products'),'📦','Products'),(url_for('customers'),'👥','Customers'),(url_for('suppliers'),'🚚','Suppliers'),(url_for('purchases'),'🛒','Purchases'),(url_for('returns'),'↩','Returns'),(url_for('expenses'),'💸','Expenses'),(url_for('reports'),'📊','Reports'),(url_for('monthly_report'),'🗓','Monthly Report'),(url_for('settings'),'⚙️','Settings'),(url_for('backup'),'💾','Backup')] %}<div class="col-6 col-md-4"><a class="card p-4 text-decoration-none" href="{{href}}"><h4>{{icon}}</h4><b>{{text}}</b></a></div>{% endfor %}</div>""")

# ---------------- PRODUCTS ----------------
@app.get("/products")
@owner_required
def products():
    q=request.args.get("q","").strip();c=db();rows=c.execute("SELECT * FROM products WHERE status='active' AND (name LIKE ? OR barcode LIKE ? OR category LIKE ?) ORDER BY name",(f"%{q}%",f"%{q}%",f"%{q}%")).fetchall() if q else c.execute("SELECT * FROM products WHERE status='active' ORDER BY name").fetchall()
    return render("پروڈکٹس / Products","""<div class="d-flex gap-2 mb-3"><form class="d-flex flex-grow-1"><input class="form-control" name="q" value="{{q}}" placeholder="{{T('search')}}"><button class="btn btn-outline-primary">🔎</button></form><a class="btn btn-primary" href="{{url_for('product_add')}}">＋ Add</a></div><div class="card p-2"><div class="table-responsive"><table class="table"><thead><tr><th>Name</th><th>Buy</th><th>Sell</th><th>Stock</th><th>Barcode</th><th></th></tr></thead><tbody>{% for p in rows %}<tr><td><b>{{p.name}}</b><br><small>{{p.category}}</small></td><td>{{money(p.buying_price)}}</td><td>{{money(p.selling_price)}}</td><td>{{p.current_stock}}</td><td>{{p.barcode or ''}}</td><td><a class="btn btn-sm btn-outline-primary" href="{{url_for('product_edit',pid=p.id)}}">✏</a> <form method="post" action="{{url_for('product_delete',pid=p.id)}}" style="display:inline" onsubmit="return confirm('Delete this product?')"><button class="btn btn-sm btn-outline-danger">🗑</button></form></td></tr>{% else %}<tr><td colspan="6" class="text-center">No products</td></tr>{% endfor %}</tbody></table></div></div>""",rows=rows,q=q)

@app.route("/products/add",methods=["GET","POST"])
@owner_required
def product_add():
    c=db()
    if request.method=="POST":
        name=request.form.get("name","").strip();buy=num(request.form.get("buying_price"));sell=num(request.form.get("selling_price"));stock=num(request.form.get("current_stock"));minstock=num(request.form.get("min_stock"));barcode=request.form.get("barcode","").strip()
        cur=c.execute("INSERT INTO products(name,category,unit,buying_price,selling_price,current_stock,min_stock,barcode,notes,status) VALUES(?,?,?,?,?,?,?,?,?,?)",(name,request.form.get("category",""),"",buy,sell,stock,minstock,barcode,request.form.get("notes",""),"active"));pid=cur.lastrowid
        if stock:c.execute("INSERT INTO stock_movements(product_id,date,type,qty_in,qty_out,balance,reference) VALUES(?,?,?,?,?,?,?)",(pid,now(),"opening",stock,0,stock,"Opening Stock"))
        c.commit();flash("Product added.","success");return redirect(url_for("products"))
    return render("نیا پروڈکٹ","""<div class="card p-3"><form method="post"><div class="row g-2"><div class="col-12"><label>Name</label><input class="form-control" name="name" required autofocus></div><div class="col-6"><label>Category</label><input class="form-control" name="category"></div><div class="col-6"><label>Buying Price</label><input class="form-control" name="buying_price" type="number" step="0.01" required></div><div class="col-6"><label>Selling Price</label><input class="form-control" name="selling_price" type="number" step="0.01" required></div><div class="col-6"><label>Opening Stock</label><input class="form-control" name="current_stock" type="number" step="0.01" value="0"></div><div class="col-6"><label>Min Stock</label><input class="form-control" name="min_stock" type="number" step="0.01" value="0"></div><div class="col-12"><label>Barcode / QR</label><div class="input-group"><input id="productBarcode" class="form-control" name="barcode" inputmode="numeric"><button type="button" class="btn btn-dark" onclick="scanProductBarcode()">📷 Scan</button></div><small class="muted">Scan with your phone camera or enter manually.</small></div><div class="col-12"><label>Notes</label><textarea class="form-control" name="notes"></textarea></div></div><button class="btn btn-primary w-100 mt-3">💾 Save Product</button></form><script>function scanProductBarcode(){if(!('BarcodeDetector' in window)){alert('Barcode scanning is not supported here. Enter the barcode manually.');return}const i=document.createElement('input');i.type='file';i.accept='image/*';i.capture='environment';i.onchange=async()=>{const img=document.createElement('img');img.src=URL.createObjectURL(i.files[0]);img.onload=async()=>{try{const d=await new BarcodeDetector().detect(img);if(d[0])document.getElementById('productBarcode').value=d[0].rawValue;else alert('No barcode found.')}catch(e){alert('Scan failed.')}}};i.click()}</script></div>""")

@app.route("/products/edit/<int:pid>",methods=["GET","POST"])
@owner_required
def product_edit(pid):
    c=db();p=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
    if not p:return redirect(url_for("products"))
    if request.method=="POST":
        buy=num(request.form.get("buying_price"));sell=num(request.form.get("selling_price"));c.execute("UPDATE products SET name=?,category=?,unit=?,buying_price=?,selling_price=?,current_stock=?,min_stock=?,barcode=?,notes=? WHERE id=?",(request.form.get("name",""),request.form.get("category",""),"",buy,sell,num(request.form.get("current_stock")),num(request.form.get("min_stock")),request.form.get("barcode",""),request.form.get("notes",""),pid));c.commit();flash("Product updated.","success");return redirect(url_for("products"))
    return render("پروڈکٹ ترمیم","""<div class="card p-3"><form method="post"><div class="row g-2">{% for field,label,val in [('name','Name',p.name),('category','Category',p.category),('buying_price','Buying Price',p.buying_price),('selling_price','Selling Price',p.selling_price),('current_stock','Current Stock',p.current_stock),('min_stock','Min Stock',p.min_stock),('barcode','Barcode',p.barcode)] %}<div class="col-12 col-sm-6"><label>{{label}}</label><input class="form-control" name="{{field}}" value="{{val or ''}}" {% if field in ['buying_price','selling_price','current_stock','min_stock'] %}type="number" step="0.01"{% endif %}></div>{% endfor %}<div class="col-12"><label>Notes</label><textarea class="form-control" name="notes">{{p.notes or ''}}</textarea></div></div><button class="btn btn-primary w-100 mt-3">Save</button></form></div>""",p=p)

# ---------------- CUSTOMERS / SUPPLIERS ----------------
def balance_for(kind,pid):
    c=db()
    if kind=="customer":
        r=c.execute("SELECT opening_balance FROM customers WHERE id=?",(pid,)).fetchone();bal=num(r[0] if r else 0);rows=c.execute("SELECT type,amount FROM customer_transactions WHERE customer_id=?",(pid,)).fetchall();return bal+sum((num(x[1]) if x[0] in ('sale','opening') else -num(x[1])) for x in rows)
    r=c.execute("SELECT opening_balance FROM suppliers WHERE id=?",(pid,)).fetchone();bal=num(r[0] if r else 0);rows=c.execute("SELECT type,amount FROM supplier_transactions WHERE supplier_id=?",(pid,)).fetchall();return bal+sum((num(x[1]) if x[0] in ('purchase','opening') else -num(x[1])) for x in rows)

@app.get("/customers")
@owner_required
def customers():
    q=request.args.get("q","").strip();c=db();rows=c.execute("SELECT * FROM customers WHERE status='active' AND (name LIKE ? OR phone LIKE ?) ORDER BY name",(f"%{q}%",f"%{q}%")).fetchall() if q else c.execute("SELECT * FROM customers WHERE status='active' ORDER BY name").fetchall();return render("گاہک / Customers","""<div class="d-flex gap-2 mb-3"><form class="d-flex flex-grow-1"><input class="form-control" name="q" value="{{q}}" placeholder="نام یا فون تلاش کریں"><button class="btn btn-outline-primary">🔎</button></form><a class="btn btn-primary" href="{{url_for('customer_add')}}">＋ Add</a></div><div class="card p-2"><div class="table-responsive"><table class="table"><tr><th>Name</th><th>Phone</th><th>Balance</th><th></th></tr>{% for x in rows %}<tr><td><b>{{x.name}}</b></td><td>{{x.phone}}</td><td>{{money(balance_for('customer',x.id))}}</td><td><a class="btn btn-sm btn-outline-primary" href="{{url_for('customer_edit',cid=x.id)}}">✏</a> <a class="btn btn-sm btn-outline-secondary" href="{{url_for('customer_ledger',cid=x.id)}}">Ledger</a> <form method="post" action="{{url_for('customer_delete',cid=x.id)}}" style="display:inline"><button class="btn btn-sm btn-outline-danger">🗑</button></form></td></tr>{% endfor %}</table></div></div>""",rows=rows,q=q,balance_for=balance_for)

@app.route("/customers/add",methods=["GET","POST"])
@owner_required
def customer_add():
    if request.method=="POST":
        c=db();c.execute("INSERT INTO customers(name,phone,address,opening_balance,notes,status) VALUES(?,?,?,?,?,?)",(request.form.get("name"),request.form.get("phone"),request.form.get("address"),num(request.form.get("opening_balance")),request.form.get("notes"),"active"));c.commit();return redirect(url_for("customers"))
    return render("نیا گاہک","""<div class="card p-3"><form method="post"><label>Name</label><input class="form-control mb-2" name="name" required><label>Phone</label><input class="form-control mb-2" name="phone"><label>Address</label><input class="form-control mb-2" name="address"><label>Opening Balance</label><input class="form-control mb-2" name="opening_balance" type="number" step="0.01"><label>Notes</label><textarea class="form-control" name="notes"></textarea><button class="btn btn-primary w-100 mt-3">Save</button></form></div>""")

@app.route("/customers/edit/<int:cid>",methods=["GET","POST"])
@owner_required
def customer_edit(cid):
    c=db();x=c.execute("SELECT * FROM customers WHERE id=?",(cid,)).fetchone()
    if request.method=="POST":c.execute("UPDATE customers SET name=?,phone=?,address=?,opening_balance=?,notes=? WHERE id=?",(request.form.get("name"),request.form.get("phone"),request.form.get("address"),num(request.form.get("opening_balance")),request.form.get("notes"),cid));c.commit();return redirect(url_for("customers"))
    return render("گاہک ترمیم","""<div class="card p-3"><form method="post"><label>Name</label><input class="form-control mb-2" name="name" value="{{x.name}}" required><label>Phone</label><input class="form-control mb-2" name="phone" value="{{x.phone or ''}}"><label>Address</label><input class="form-control mb-2" name="address" value="{{x.address or ''}}"><label>Opening Balance</label><input class="form-control mb-2" name="opening_balance" value="{{x.opening_balance}}" type="number" step="0.01"><label>Notes</label><textarea class="form-control" name="notes">{{x.notes or ''}}</textarea><button class="btn btn-primary w-100 mt-3">Save</button></form></div>""",x=x)

@app.get("/customers/ledger/<int:cid>")
@owner_required
def customer_ledger(cid):
    x=db().execute("SELECT * FROM customers WHERE id=?",(cid,)).fetchone();rows=db().execute("SELECT * FROM customer_transactions WHERE customer_id=? ORDER BY id DESC",(cid,)).fetchall();return render("گاہک کھاتہ","""<div class="card p-3"><h4>{{x.name}}</h4><div class="alert alert-info">Current Balance: <b>{{money(balance_for('customer',x.id))}}</b></div><form method="post" action="{{url_for('customer_payment',cid=x.id)}}" class="d-flex gap-2 mb-3"><input class="form-control" name="amount" type="number" step="0.01" placeholder="Payment received" required><button class="btn btn-success">Receive Payment</button></form><div class="table-responsive"><table class="table"><tr><th>Date</th><th>Type</th><th>Amount</th><th>Description</th></tr>{% for r in rows %}<tr><td>{{r.date}}</td><td>{{r.type}}</td><td>{{money(r.amount)}}</td><td>{{r.description}}</td></tr>{% endfor %}</table></div></div>""",x=x,rows=rows,balance_for=balance_for)

@app.get("/suppliers")
@owner_required
def suppliers():
    q=request.args.get("q","").strip();c=db();rows=c.execute("SELECT * FROM suppliers WHERE status='active' AND (name LIKE ? OR phone LIKE ? OR company LIKE ?) ORDER BY name",(f"%{q}%",f"%{q}%",f"%{q}%")).fetchall() if q else c.execute("SELECT * FROM suppliers WHERE status='active' ORDER BY name").fetchall();return render("سپلائرز / Suppliers","""<div class="d-flex gap-2 mb-3"><form class="d-flex flex-grow-1"><input class="form-control" name="q" value="{{q}}" placeholder="سپلائر کا نام تلاش کریں"><button class="btn btn-outline-primary">🔎</button></form><a class="btn btn-primary" href="{{url_for('supplier_add')}}">＋ Add</a></div><div class="card p-2"><div class="table-responsive"><table class="table"><tr><th>Name</th><th>Company</th><th>Phone</th><th>Balance</th><th></th></tr>{% for x in rows %}<tr><td><b>{{x.name}}</b></td><td>{{x.company}}</td><td>{{x.phone}}</td><td>{{money(balance_for('supplier',x.id))}}</td><td><a class="btn btn-sm btn-outline-primary" href="{{url_for('supplier_edit',sid=x.id)}}">✏</a> <a class="btn btn-sm btn-outline-secondary" href="{{url_for('supplier_ledger',sid=x.id)}}">Ledger</a> <form method="post" action="{{url_for('supplier_delete',sid=x.id)}}" style="display:inline"><button class="btn btn-sm btn-outline-danger">🗑</button></form></td></tr>{% endfor %}</table></div></div>""",rows=rows,q=q,balance_for=balance_for)

@app.route("/suppliers/add",methods=["GET","POST"])
@owner_required
def supplier_add():
    if request.method=="POST":
        c=db();c.execute("INSERT INTO suppliers(name,phone,company,address,opening_balance,notes,status) VALUES(?,?,?,?,?,?,?)",(request.form.get("name"),request.form.get("phone"),request.form.get("company"),request.form.get("address"),num(request.form.get("opening_balance")),request.form.get("notes"),"active"));c.commit();return redirect(url_for("suppliers"))
    return render("نیا سپلائر","""<div class="card p-3"><form method="post"><label>Name</label><input class="form-control mb-2" name="name" required><label>Company</label><input class="form-control mb-2" name="company"><label>Phone</label><input class="form-control mb-2" name="phone"><label>Address</label><input class="form-control mb-2" name="address"><label>Opening Balance</label><input class="form-control mb-2" name="opening_balance" type="number" step="0.01"><label>Notes</label><textarea class="form-control" name="notes"></textarea><button class="btn btn-primary w-100 mt-3">Save</button></form></div>""")

@app.route("/suppliers/edit/<int:sid>",methods=["GET","POST"])
@owner_required
def supplier_edit(sid):
    c=db();x=c.execute("SELECT * FROM suppliers WHERE id=?",(sid,)).fetchone()
    if request.method=="POST":c.execute("UPDATE suppliers SET name=?,phone=?,company=?,address=?,opening_balance=?,notes=? WHERE id=?",(request.form.get("name"),request.form.get("phone"),request.form.get("company"),request.form.get("address"),num(request.form.get("opening_balance")),request.form.get("notes"),sid));c.commit();return redirect(url_for("suppliers"))
    return render("سپلائر ترمیم","""<div class="card p-3"><form method="post"><div class="row g-2"><div class="col-12"><label>Name</label><input class="form-control" name="name" value="{{x.name}}" required></div><div class="col-6"><label>Company</label><input class="form-control" name="company" value="{{x.company or ''}}"></div><div class="col-6"><label>Phone</label><input class="form-control" name="phone" value="{{x.phone or ''}}"></div><div class="col-12"><label>Address</label><input class="form-control" name="address" value="{{x.address or ''}}"></div><div class="col-12"><label>Opening Balance</label><input class="form-control" name="opening_balance" value="{{x.opening_balance}}" type="number" step="0.01"></div><div class="col-12"><label>Notes</label><textarea class="form-control" name="notes">{{x.notes or ''}}</textarea></div></div><button class="btn btn-primary w-100 mt-3">Save</button></form></div>""",x=x)

@app.get("/suppliers/ledger/<int:sid>")
@owner_required
def supplier_ledger(sid):
    x=db().execute("SELECT * FROM suppliers WHERE id=?",(sid,)).fetchone();rows=db().execute("SELECT * FROM supplier_transactions WHERE supplier_id=? ORDER BY id DESC",(sid,)).fetchall();return render("سپلائر کھاتہ","""<div class="card p-3"><h4>{{x.name}}</h4><div class="alert alert-warning">Current Payable: <b>{{money(balance_for('supplier',x.id))}}</b></div><form method="post" action="{{url_for('supplier_payment',sid=x.id)}}" class="d-flex gap-2 mb-3"><input class="form-control" name="amount" type="number" step="0.01" placeholder="Payment made" required><button class="btn btn-danger">Pay Supplier</button></form><div class="table-responsive"><table class="table"><tr><th>Date</th><th>Type</th><th>Amount</th><th>Description</th></tr>{% for r in rows %}<tr><td>{{r.date}}</td><td>{{r.type}}</td><td>{{money(r.amount)}}</td><td>{{r.description}}</td></tr>{% endfor %}</table></div></div>""",x=x,rows=rows,balance_for=balance_for)

# ---------------- RETURNS ----------------
@app.route("/returns",methods=["GET","POST"])
@owner_required
def returns():
    c=db();rows=c.execute("SELECT r.*,CASE WHEN r.type='customer' THEN c.name ELSE s.name END party_name FROM returns r LEFT JOIN customers c ON r.type='customer' AND c.id=r.party_id LEFT JOIN suppliers s ON r.type='supplier' AND s.id=r.party_id ORDER BY r.id DESC LIMIT 50").fetchall()
    if request.method=="POST":
        typ=request.form.get("type");pid=int(request.form.get("product_id",0));qty=num(request.form.get("quantity"));price=num(request.form.get("price"));party=request.form.get("party_id") or None;party=int(party) if party and party.isdigit() else None;p=c.execute("SELECT * FROM products WHERE id=?",(pid,)).fetchone()
        if not p or qty<=0 or price<0:flash("Invalid return data.","danger");return redirect(url_for("returns"))
        if typ=="customer" and qty>num(p["current_stock"])+qty: pass
        total=qty*price
        try:
            c.execute("BEGIN");cur=c.execute("INSERT INTO returns(date,type,ref_id,party_id,total_amount,reason,discount) VALUES(?,?,?,?,?,?,0)",(now(),typ,None,party,total,request.form.get("reason","")));rid=cur.lastrowid;c.execute("INSERT INTO return_items(return_id,product_id,quantity,price,total) VALUES(?,?,?,?,?)",(rid,pid,qty,price,total))
            old=num(p["current_stock"]);new=old+qty if typ=="customer" else old-qty
            if new<0:raise ValueError("Not enough stock for supplier return")
            c.execute("UPDATE products SET current_stock=? WHERE id=?",(new,pid));c.execute("INSERT INTO stock_movements(product_id,date,type,qty_in,qty_out,balance,reference) VALUES(?,?,?,?,?,?,?)",(pid,now(),"customer_return" if typ=="customer" else "supplier_return",qty if typ=="customer" else 0,qty if typ=="supplier" else 0,new,f"Return #{rid}"))
            if party and typ=="customer":c.execute("INSERT INTO customer_transactions(customer_id,date,type,ref_id,amount,description) VALUES(?,?,?,?,?,?)",(party,now(),"return",rid,total,"Customer return - balance reduced"))
            if party and typ=="supplier":c.execute("INSERT INTO supplier_transactions(supplier_id,date,type,ref_id,amount,description) VALUES(?,?,?,?,?,?)",(party,now(),"return",rid,total,"Supplier return - payable reduced"))
            c.commit();flash("Return saved and stock adjusted.","success")
        except Exception as e:c.rollback();flash(str(e),"danger")
        return redirect(url_for("returns"))
    products_list=c.execute("SELECT id,name,barcode,selling_price,buying_price,current_stock,unit FROM products WHERE status='active' ORDER BY name").fetchall();customers_list=c.execute("SELECT id,name FROM customers WHERE status='active' ORDER BY name").fetchall();suppliers_list=c.execute("SELECT id,name FROM suppliers WHERE status='active' ORDER BY name").fetchall()
    return render("واپسی / Returns","""<div class="row g-3"><div class="col-lg-6"><div class="card p-3"><h5>↩ Customer Return</h5><form method="post"><input type="hidden" name="type" value="customer"><label>Customer (optional)</label><select class="form-select mb-2" name="party_id"><option value="">Walk-in</option>{% for x in customers_list %}<option value="{{x.id}}">{{x.name}}</option>{% endfor %}</select><label>Product</label><select class="form-select mb-2" name="product_id">{% for p in products_list %}<option value="{{p.id}}">{{p.name}} — {{money(p.selling_price)}}</option>{% endfor %}</select><label>Quantity</label><input class="form-control mb-2" name="quantity" type="number" step="0.01" value="1"><label>Refund/Adjustment Price</label><input class="form-control mb-2" name="price" type="number" step="0.01"><label>Reason</label><input class="form-control mb-3" name="reason"><button class="btn btn-success w-100">Save Customer Return</button></form></div></div><div class="col-lg-6"><div class="card p-3"><h5>↩ Supplier Return</h5><form method="post"><input type="hidden" name="type" value="supplier"><label>Supplier (optional)</label><select class="form-select mb-2" name="party_id"><option value="">Unknown</option>{% for x in suppliers_list %}<option value="{{x.id}}">{{x.name}}</option>{% endfor %}</select><label>Product</label><select class="form-select mb-2" name="product_id">{% for p in products_list %}<option value="{{p.id}}">{{p.name}} — buy {{money(p.buying_price)}}</option>{% endfor %}</select><label>Quantity</label><input class="form-control mb-2" name="quantity" type="number" step="0.01" value="1"><label>Return Price</label><input class="form-control mb-2" name="price" type="number" step="0.01"><label>Reason</label><input class="form-control mb-3" name="reason"><button class="btn btn-danger w-100">Save Supplier Return</button></form></div></div></div><div class="card p-3 mt-3"><h5>Recent Returns</h5><div class="table-responsive"><table class="table"><tr><th>Date</th><th>Type</th><th>Party</th><th>Total</th><th>Reason</th></tr>{% for r in rows %}<tr><td>{{r.date}}</td><td>{{r.type}}</td><td>{{r.party_name or '-'}}</td><td>{{money(r.total_amount)}}</td><td>{{r.reason}}</td></tr>{% endfor %}</table></div></div>""",rows=rows,products_list=products_list,customers_list=customers_list,suppliers_list=suppliers_list)

# ---------------- EXPENSES / REPORTS / SETTINGS / BACKUP ----------------
@app.route("/expenses",methods=["GET","POST"])
@owner_required
def expenses():
    c=db()
    if request.method=="POST":c.execute("INSERT INTO expenses(date,category,amount,description) VALUES(?,?,?,?)",(now(),request.form.get("category"),num(request.form.get("amount")),request.form.get("description")));c.commit();return redirect(url_for("expenses"))
    rows=c.execute("SELECT * FROM expenses ORDER BY id DESC LIMIT 100").fetchall();return render("اخراجات / Expenses","""<div class="card p-3 mb-3"><form method="post" class="row g-2"><div class="col-6"><input class="form-control" name="category" placeholder="Category" required></div><div class="col-6"><input class="form-control" name="amount" type="number" step="0.01" placeholder="Amount" required></div><div class="col-12"><input class="form-control" name="description" placeholder="Description"></div><div class="col-12"><button class="btn btn-danger w-100">Add Expense</button></div></form></div><div class="card p-2"><table class="table"><tr><th>Date</th><th>Category</th><th>Amount</th><th>Description</th></tr>{% for r in rows %}<tr><td>{{r.date}}</td><td>{{r.category}}</td><td>{{money(r.amount)}}</td><td>{{r.description}}</td></tr>{% endfor %}</table></div>""",rows=rows)

@app.get("/reports")
@owner_required
def reports():
    c=db();start=request.args.get("start",today());end=request.args.get("end",today());s=num(c.execute("SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE substr(date,1,10) BETWEEN ? AND ?",(start,end)).fetchone()[0]);p=num(c.execute("SELECT COALESCE(SUM(profit),0) FROM sale_items i JOIN sales s ON s.id=i.sale_id WHERE substr(s.date,1,10) BETWEEN ? AND ?",(start,end)).fetchone()[0]);exp=num(c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE substr(date,1,10) BETWEEN ? AND ?",(start,end)).fetchone()[0]);count=c.execute("SELECT COUNT(*) FROM sales WHERE substr(date,1,10) BETWEEN ? AND ?",(start,end)).fetchone()[0]
    rows=c.execute("SELECT s.id,s.date,COALESCE(c.name,'Walk-in') customer,s.total_amount,s.discount,s.paid_amount,s.credit_amount FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE substr(s.date,1,10) BETWEEN ? AND ? ORDER BY s.id DESC",(start,end)).fetchall()
    return render("رپورٹس / Reports","""<div class="card p-3 mb-3"><form class="row g-2"><div class="col-5"><input class="form-control" type="date" name="start" value="{{start}}"></div><div class="col-5"><input class="form-control" type="date" name="end" value="{{end}}"></div><div class="col-2"><button class="btn btn-primary w-100">Go</button></div></form></div><div class="row g-2"><div class="col-6 col-md-3"><div class="stat"><small>Sales</small><h4>{{money(s)}}</h4></div></div><div class="col-6 col-md-3"><div class="stat"><small>Profit</small><h4 class="text-success">{{money(p)}}</h4></div></div><div class="col-6 col-md-3"><div class="stat"><small>Expenses</small><h4 class="text-danger">{{money(exp)}}</h4></div></div><div class="col-6 col-md-3"><div class="stat"><small>Bills</small><h4>{{count}}</h4></div></div></div><div class="card p-2 mt-3"><div class="table-responsive"><table class="table"><tr><th>#</th><th>Date</th><th>Customer</th><th>Total</th><th>Paid</th><th>Credit</th><th></th></tr>{% for r in rows %}<tr><td>{{r.id}}</td><td>{{r.date}}</td><td>{{r.customer}}</td><td>{{money(r.total_amount)}}</td><td>{{money(r.paid_amount)}}</td><td>{{money(r.credit_amount)}}</td><td><a class="btn btn-sm btn-outline-primary" href="{{url_for('sale_invoice',sid=r.id)}}">Bill</a></td></tr>{% endfor %}</table></div></div>""",start=start,end=end,s=s,p=p,exp=exp,count=count,rows=rows)

@app.route("/settings",methods=["GET","POST"])
@owner_required
def settings():
    c=db();x=c.execute("SELECT * FROM settings LIMIT 1").fetchone()
    if request.method=="POST":
        c.execute("UPDATE settings SET shop_name=?,owner_name=?,phone=?,address=?,language=?,currency=? WHERE id=?",(request.form.get("shop_name"),request.form.get("owner_name"),request.form.get("phone"),request.form.get("address"),request.form.get("language"),request.form.get("currency"),x["id"]));
        newpass=request.form.get("new_password","").strip()
        if newpass:c.execute("UPDATE users SET password_hash=? WHERE username=?",(hash_password(newpass),session.get("owner_user","admin")))
        c.commit();session["lang"]=request.form.get("language","ur");flash("Settings saved.","success");return redirect(url_for("settings"))
    return render("ترتیبات / Settings","""<div class="card p-3"><form method="post"><label>Shop Name</label><input class="form-control mb-2" name="shop_name" value="{{x.shop_name}}"><label>Owner Name</label><input class="form-control mb-2" name="owner_name" value="{{x.owner_name}}"><label>Phone</label><input class="form-control mb-2" name="phone" value="{{x.phone or ''}}"><label>Address</label><input class="form-control mb-2" name="address" value="{{x.address or ''}}"><label>Language</label><select class="form-select mb-2" name="language"><option value="ur" {% if x.language=='ur' %}selected{% endif %}>Urdu</option><option value="en" {% if x.language=='en' %}selected{% endif %}>English</option></select><label>Currency</label><input class="form-control mb-2" name="currency" value="{{x.currency or 'Rs'}}"><hr><label>New Owner Password</label><input class="form-control" name="new_password" type="password" placeholder="Leave blank to keep current"><div class="small muted mt-2">Default password is 1234 only on a new database. Change it here.</div><button class="btn btn-primary w-100 mt-3">Save Settings</button></form></div>""",x=x)

@app.get("/backup")
@owner_required
def backup():
    os.makedirs(BACKUP_DIR,exist_ok=True);path=os.path.join(BACKUP_DIR,f"retailpro_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db");shutil.copy2(DB_NAME,path);return send_file(path,as_attachment=True,download_name=os.path.basename(path))

# ---------------- INVOICE ----------------
def invoice_data(sid):
    c=db();s=c.execute("SELECT s.*,COALESCE(c.name,'Walk-in / Cash') customer,COALESCE(c.phone,'') phone FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.id=?",(sid,)).fetchone();items=c.execute("SELECT i.*,p.name FROM sale_items i JOIN products p ON p.id=i.product_id WHERE i.sale_id=?",(sid,)).fetchall();return s,items

@app.get("/sales/invoice/<int:sid>")
def sale_invoice(sid):
    s,items=invoice_data(sid)
    if not s:return redirect(url_for("sales"))
    return render(f"Bill #{sid}","""<div class="invoice"><div class="text-center"><h2>{{shop_name}}</h2><div>{{owner_name}}</div><div>{{phone}}</div></div><hr><div class="d-flex justify-content-between"><span>Bill #{{s.id}}</span><span>{{s.date}}</span></div><div class="mt-2"><b>Customer:</b> {{s.customer}} {% if s.phone %} — {{s.phone}}{% endif %}</div><div class="table-responsive mt-3"><table class="table"><tr><th>Item</th><th>Qty</th><th>Rate</th><th>Total</th></tr>{% for x in items %}<tr><td>{{x.name}}</td><td>{{x.quantity}}</td><td>{{money(x.selling_price)}}</td><td>{{money(x.total)}}</td></tr>{% endfor %}</table></div><div class="ms-auto" style="max-width:360px"><div class="d-flex justify-content-between"><span>Subtotal</span><b>{{money(s.subtotal)}}</b></div><div class="d-flex justify-content-between"><span>Discount</span><b>{{money(s.discount)}}</b></div><div class="d-flex justify-content-between fs-5"><span>Total</span><b>{{money(s.total_amount)}}</b></div><div class="d-flex justify-content-between"><span>Paid</span><b>{{money(s.paid_amount)}}</b></div><div class="d-flex justify-content-between"><span>Change</span><b>{{money(s.change_amount or 0)}}</b></div><div class="d-flex justify-content-between"><span>Credit</span><b>{{money(s.credit_amount)}}</b></div></div><div class="no-print d-flex gap-2 mt-4"><button class="btn btn-dark" onclick="window.print()">🖨 {{T('print')}}</button><a class="btn btn-primary" href="{{url_for('sale_pdf',sid=s.id)}}">📄 {{T('pdf')}}</a><a class="btn btn-outline-success" href="{{url_for('sales')}}">New Sale</a></div></div>""",s=s,items=items,shop_name=db().execute("SELECT shop_name FROM settings LIMIT 1").fetchone()[0],owner_name=db().execute("SELECT owner_name FROM settings LIMIT 1").fetchone()[0],phone=db().execute("SELECT phone FROM settings LIMIT 1").fetchone()[0])

@app.get("/sales/invoice/<int:sid>/pdf")
def sale_pdf(sid):
    s,items=invoice_data(sid)
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.pdfbase import pdfmetrics
        from reportlab.lib.units import mm
        path=os.path.join("/tmp",f"retailpro_bill_{sid}.pdf")
        c=canvas.Canvas(path,pagesize=A4);w,h=A4;y=h-20*mm
        # Use a Unicode font if available; otherwise standard Helvetica still works for English/numbers.
        font="Helvetica";font_path="/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
        if os.path.exists(font_path):pdfmetrics.registerFont(TTFont("DejaVu",font_path));font="DejaVu"
        pdf_en=(lang()=="en"); labels={"customer":"Customer" if pdf_en else "گاہک","item":"Item" if pdf_en else "آئٹم","qty":"Qty" if pdf_en else "مقدار","rate":"Rate" if pdf_en else "ریٹ","total":"Total" if pdf_en else "کل","subtotal":"Subtotal" if pdf_en else "ذیلی کل","discount":"Discount" if pdf_en else "ڈسکاؤنٹ","paid":"Paid" if pdf_en else "جمع رقم","credit":"Credit" if pdf_en else "ادھار"}
        c.setFont(font,16);c.drawString(20*mm,y,"RetailPro Shop Manager");y-=10*mm;c.setFont(font,10);c.drawString(20*mm,y,f"Bill #{sid}   {s['date']}");y-=7*mm;c.drawString(20*mm,y,f"{labels['customer']}: {s['customer']}");y-=10*mm
        c.drawString(20*mm,y,labels["item"]);c.drawString(100*mm,y,labels["qty"]);c.drawString(125*mm,y,labels["rate"]);c.drawString(155*mm,y,labels["total"]);y-=6*mm
        for x in items:
            if y<25*mm:c.showPage();y=h-20*mm;c.setFont(font,10)
            name=str(x["name"])[:38];c.drawString(20*mm,y,name);c.drawRightString(118*mm,y,f"{num(x['quantity']):g}");c.drawRightString(150*mm,y,f"{num(x['selling_price']):,.2f}");c.drawRightString(190*mm,y,f"{num(x['total']):,.2f}");y-=6*mm
        y-=4*mm;c.line(120*mm,y,190*mm,y);y-=7*mm
        for label,val in [(labels["subtotal"],s["subtotal"]),(labels["discount"],s["discount"]),(labels["total"],s["total_amount"]),(labels["paid"],s["paid_amount"]),(labels["credit"],s["credit_amount"])]:c.drawString(125*mm,y,label);c.drawRightString(190*mm,y,f"Rs {num(val):,.2f}");y-=6*mm
        c.save();return send_file(path,as_attachment=True,download_name=f"RetailPro_Bill_{sid}.pdf",mimetype="application/pdf")
    except ImportError:return redirect(url_for("sale_invoice",sid=sid))


# ---------------- PAYMENTS / DELETE / CLOSING ----------------
@app.post("/customers/<int:cid>/payment")
@owner_required
def customer_payment(cid):
    amount=max(0,num(request.form.get("amount"))); c=db()
    if amount: c.execute("INSERT INTO customer_transactions(customer_id,date,type,ref_id,amount,description) VALUES(?,?,?,?,?,?)",(cid,now(),"payment",None,amount,"Customer payment received")); c.commit()
    return redirect(url_for("customer_ledger",cid=cid))

@app.post("/suppliers/<int:sid>/payment")
@owner_required
def supplier_payment(sid):
    amount=max(0,num(request.form.get("amount"))); c=db()
    if amount: c.execute("INSERT INTO supplier_transactions(supplier_id,date,type,ref_id,amount,description) VALUES(?,?,?,?,?,?)",(sid,now(),"payment",None,amount,"Supplier payment made")); c.commit()
    return redirect(url_for("supplier_ledger",sid=sid))

@app.post("/products/delete/<int:pid>")
@owner_required
def product_delete(pid):
    c=db();c.execute("UPDATE products SET status='deleted' WHERE id=?",(pid,));c.commit();return redirect(url_for("products"))
@app.post("/customers/delete/<int:cid>")
@owner_required
def customer_delete(cid):
    c=db();c.execute("UPDATE customers SET status='deleted' WHERE id=?",(cid,));c.commit();return redirect(url_for("customers"))
@app.post("/suppliers/delete/<int:sid>")
@owner_required
def supplier_delete(sid):
    c=db();c.execute("UPDATE suppliers SET status='deleted' WHERE id=?",(sid,));c.commit();return redirect(url_for("suppliers"))

@app.route("/daily-closing",methods=["GET","POST"])
@owner_required
def daily_closing():
    c=db();d=request.form.get("close_date",today()) if request.method=="POST" else request.args.get("date",today())
    if request.method=="POST":
        sales=num(c.execute("SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE substr(date,1,10)=?",(d,)).fetchone()[0]);credit=num(c.execute("SELECT COALESCE(SUM(credit_amount),0) FROM sales WHERE substr(date,1,10)=?",(d,)).fetchone()[0]);exp=num(c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE substr(date,1,10)=?",(d,)).fetchone()[0]);gross=num(c.execute("SELECT COALESCE(SUM(profit),0) FROM sale_items i JOIN sales s ON s.id=i.sale_id WHERE substr(s.date,1,10)=?",(d,)).fetchone()[0]);profit=gross-exp
        c.execute("INSERT OR REPLACE INTO daily_closings(close_date,closed_at,sales,credit,expenses,profit) VALUES(?,?,?,?,?,?)",(d,now(),sales,credit,exp,profit));c.commit();flash("Daily closing saved.","success")
    r=c.execute("SELECT * FROM daily_closings ORDER BY close_date DESC LIMIT 30").fetchall()
    return render("Daily Closing","""<div class="card p-3 mb-3"><form method="post"><label>Date</label><input class="form-control mb-2" type="date" name="close_date" value="{{d}}"><button class="btn btn-primary w-100">🌙 Close Day</button></form></div><div class="card p-2"><div class="table-responsive"><table class="table"><tr><th>Date</th><th>Sales</th><th>Credit</th><th>Expenses</th><th>Profit</th></tr>{% for x in r %}<tr><td>{{x.close_date}}</td><td>{{money(x.sales)}}</td><td>{{money(x.credit)}}</td><td>{{money(x.expenses)}}</td><td>{{money(x.profit)}}</td></tr>{% endfor %}</table></div></div>""",d=d,r=r)


@app.get("/monthly-report")
@owner_required
def monthly_report():
    c=db(); today_d=date.today(); first=today_d.replace(day=1)
    end=today_d
    s=num(c.execute("SELECT COALESCE(SUM(total_amount),0) FROM sales WHERE substr(date,1,10) BETWEEN ? AND ?",(first.isoformat(),end.isoformat())).fetchone()[0])
    credit=num(c.execute("SELECT COALESCE(SUM(credit_amount),0) FROM sales WHERE substr(date,1,10) BETWEEN ? AND ?",(first.isoformat(),end.isoformat())).fetchone()[0])
    gross=num(c.execute("SELECT COALESCE(SUM(profit),0) FROM sale_items i JOIN sales s ON s.id=i.sale_id WHERE substr(s.date,1,10) BETWEEN ? AND ?",(first.isoformat(),end.isoformat())).fetchone()[0])
    exp=num(c.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE substr(date,1,10) BETWEEN ? AND ?",(first.isoformat(),end.isoformat())).fetchone()[0])
    return render("Monthly Report","""<div class="card p-3"><h4>{{first}} to {{end}}</h4><div class="row g-2 mt-2">{% for l,v in [('Sales',s),('Credit',credit),('Expenses',exp),('Gross Profit',gross),('Net Profit',gross-exp)] %}<div class="col-6 col-md-4"><div class="stat"><small>{{l}}</small><h4>{{money(v)}}</h4></div></div>{% endfor %}</div><p class="muted mt-3">This report is generated automatically for the current month. Daily closing records are stored separately.</p></div>""",first=first.isoformat(),end=end.isoformat(),s=s,credit=credit,exp=exp,gross=gross)

# ---------------- HEALTH / START ----------------
@app.get("/health")
def health():return jsonify(ok=True,app="RetailPro Shop Manager")

if __name__=="__main__":
    print("\n============================================")
    print("RetailPro Shop Manager - Ready")
    print("Sales screen (staff): http://127.0.0.1:5000/sales")
    print("Owner management:     http://127.0.0.1:5000/owner-login")
    print("Default owner login:  admin / 1234")
    print("============================================\n")
    app.run(host="0.0.0.0",port=5000,debug=False)
