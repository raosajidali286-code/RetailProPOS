# -*- coding: utf-8 -*-
"""
Android launcher for RetailPro Commercial.

This file does NOT change the application. The original program is included
unchanged as retailpro_app.py. This launcher only does what Android needs:
  1. keep the database/backups in the app's private storage,
  2. point the "/tmp" path used for PDF bills at a writable folder,
  3. keep a stable (per-install) session secret,
  4. start the original Flask app on 127.0.0.1 so the in-app WebView can show it.
"""
import os
import sys
import secrets

HERE = os.path.dirname(os.path.abspath(__file__))
ON_ANDROID = "ANDROID_ARGUMENT" in os.environ


def data_dir():
    if ON_ANDROID:
        base = os.environ.get("ANDROID_PRIVATE") or HERE
    else:
        base = os.environ.get("RETAILPRO_HOME") or os.path.join(HERE, "_desktop_data")
    d = os.path.join(base, "retailpro_data")
    os.makedirs(d, exist_ok=True)
    return d


DATA = data_dir()
os.chdir(DATA)  # app uses relative paths: retailpro_shop.db and retailpro_backups/
TMP = os.path.join(DATA, "tmp")
os.makedirs(TMP, exist_ok=True)

# Stable random secret per install (instead of the shared hard-coded default).
if "RETAILPRO_SECRET" not in os.environ:
    sp = os.path.join(DATA, ".secret")
    if not os.path.exists(sp):
        with open(sp, "w") as f:
            f.write(secrets.token_hex(32))
    with open(sp) as f:
        os.environ["RETAILPRO_SECRET"] = f.read().strip()

sys.path.insert(0, HERE)
import retailpro_app as rp  # noqa: E402  (creates/updates the database on import)


class _PathShim:
    """Same as os.path, but maps the hard-coded '/tmp' (missing on Android) to TMP."""
    def __init__(self, real):
        self._real = real

    def join(self, *parts):
        if parts and parts[0] == "/tmp":
            parts = (TMP,) + tuple(parts[1:])
        return self._real.join(*parts)

    def __getattr__(self, name):
        return getattr(self._real, name)


class _OsShim:
    def __init__(self, real):
        self._real = real
        self.path = _PathShim(real.path)

    def __getattr__(self, name):
        return getattr(self._real, name)


rp.os = _OsShim(os)  # affects only the app module's own reference to os
# Flask resolves relative send_file() paths (backup download) against root_path;
# on Android the code folder is read-only, so use the data folder instead.
rp.app.root_path = DATA

PORT = int(os.environ.get("RETAILPRO_PORT", "5000"))

if __name__ == "__main__":
    rp.app.run(host="127.0.0.1", port=PORT, debug=False, use_reloader=False, threaded=True)
